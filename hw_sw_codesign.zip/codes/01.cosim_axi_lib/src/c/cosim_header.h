#pragma once
/**
 * @file cosim_header.h
 *
 */
//------------------------------------------------------------------------------
// Copyright (c) 2022 by Ando Ki.
// All rights reserved by Ando Ki.
//------------------------------------------------------------------------------
// cosim_header.h
//------------------------------------------------------------------------------
#include <stdint.h>

/**
 * @struct cosim_header_t
 *
 * @brief Packet format
 *
 * @var cosim_header_t::id    transaction identification number
 * @var cosim_header_t::cmd   TERM-REQ(8) TERM-RSP(9)
 * @var cosim_header_t::ack   ERR(0), OK(1); used when TERM-RSP
 * @var cosim_header_t::attr  user-specified attribute
 * @var cosim_header_t::size  number of size of data to be followed
 */
#pragma pack(1)
typedef struct __attribute__ ((__packed__)) cosim_header {
  uint32_t id;       // transaction identification number
  uint32_t cmd;      // TERM-REQ(8) TERM-RSP(9)
  uint32_t ack;      // ERR(0), OK(1); used when TERM-RSP
  uint32_t attr;     // user-specified attribute
  uint32_t size;     // number of size of data to be followed
} cosim_header_t;
#pragma pack()

//------------------------------------------------------------------------------
// Revision history:
//
// 2022.11.18: Modified for generic cosim
// 2021.07.01: Started by Ando Ki (andoki@gmail.com)
//------------------------------------------------------------------------------
