#ifndef COSIM_API_H
#define COSIM_API_H
//------------------------------------------------------------------------------
// Copyright (c) 2021 by Ando Ki.
// All rights reserved by Ando Ki.
//------------------------------------------------------------------------------
// cosim_api.h
//------------------------------------------------------------------------------
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

//------------------------------------------------------------------------------
// for BFM master API
extern int cosim_open( int   cid
                     , int   type
                     , int   server_port
                     , char *server_ip );
int cosim_open_server( int   cid
                     , int   port );
int cosim_open_client( int   cid
                     , int   server_port );
extern int cosim_close  ( int cid );
extern int cosim_barrier( int cid );
extern int cosim_set_verbose( int level );
extern int cosim_get_verbose();
//------------------------------------------------------------------------------
extern int cosim_snd( int   cid
                    , char *payload
                    , int   size);

extern int cosim_rcv( int   cid
                    , char *payload
                    , int   size);

//------------------------------------------------------------------------------
#ifdef __cplusplus
}
#endif

//------------------------------------------------------------------------------
// Revision history
//
// 2021.07.01: Started by Ando Ki (andoki@gmail.com)
//------------------------------------------------------------------------------
#endif
