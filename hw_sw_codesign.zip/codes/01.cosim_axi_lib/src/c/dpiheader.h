/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2020 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/


/* NOTE: DO NOT EDIT. AUTOMATICALLY GENERATED FILE. CHANGES WILL BE LOST. */

#ifndef DPI_H
#define DPI_H
#ifdef __cplusplus
#define DPI_LINKER_DECL  extern "C" 
#else
#define DPI_LINKER_DECL
#endif

#include "svdpi.h"



/* Imported (by SV) function */
DPI_LINKER_DECL DPI_DLLESPEC 
 int cosim_dpi_open(
	int cid ,
	int port);


/* Imported (by SV) function */
DPI_LINKER_DECL DPI_DLLESPEC 
 int cosim_dpi_close(
	int cid);


/* Imported (by SV) function */
DPI_LINKER_DECL DPI_DLLESPEC 
 int cosim_dpi_barrier(
	int cid);


/* Imported (by SV) function */
DPI_LINKER_DECL DPI_DLLESPEC 
 int cosim_dpi_rcv(
	int cid ,
	const svOpenArrayHandle pkt_data ,
	int bnum);


/* Imported (by SV) function */
DPI_LINKER_DECL DPI_DLLESPEC 
 int cosim_dpi_snd(
	int cid ,
	const svOpenArrayHandle pkt_data ,
	int bnum);


/* Imported (by SV) function */
DPI_LINKER_DECL DPI_DLLESPEC 
 int cosim_dpi_set_verbose(
	int level);


#endif
