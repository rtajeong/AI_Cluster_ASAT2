#pragma once
/*
 * Copyright (c) 2022 by Future Design Systems.
 * All right reserved.
 * http://www.future-ds.com
 *
 * @file cosim_socket.h
 * @brief This file contains functions for XDMA lowlevel.
 * @author Ando Ki
 * @date 2022.11.05.
 */

#ifdef __cplusplus
extern "C" {
#endif

#define COSIM_SOCKET_API_VERSION   "0x20221105"
#define COSIM_SOCKET_TYPE_SERVER    1
#define COSIM_SOCKET_TYPE_CLIENT    2
#define COSIM_SOCKET_MODE_BLOCK     0
#define COSIM_SOCKET_MODE_NONBLOCK  1

struct CosimSocketHandle {
    int type; // 1: server, 2:client
    int sock;
    int port;
    int mode; // 0: blocking, 1: nonblocking
};

typedef struct CosimSocketHandle *CosimSocketHandle_t;

CosimSocketHandle_t socket_init_server( int   port
                                      , int   nonblock );
CosimSocketHandle_t socket_init_client( int   server_port
                                      , char *server_ip
                                      , int   nonblock );
int socket_release( CosimSocketHandle_t handle );
int socket_read( CosimSocketHandle_t handle, char *buff, int size );
int socket_write( CosimSocketHandle_t handle, char *buff, int size );
int socket_get_socket_buffer( int sock );
int socket_set_socket_buffer( int sock, int size );

#ifdef __cplusplus
}
#endif

/* Revision history
 *
 * 2022.11.05: Updated.
 * 2022.10.15: Started by Ando Ki (adki@future-ds.com)
 */
