//------------------------------------------------------------------------------
// Copyright (c) 2021 by Ando Ki.
// All rights reserved by Ando Ki.
//------------------------------------------------------------------------------
// cosim_vpi.c
//------------------------------------------------------------------------------
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#if defined(WIN32)  // cygwin use this
#       include <windows.h>
#       include <io.h>
#       include <process.h>
#else
#       include <unistd.h>
#endif
#include "vpi_user.h"
#include "cosim_defines.h"
#include "cosim_api.h"

//------------------------------------------------------------------------------
static int m_verbose = 0;
static int m_cid_max = COSIM_MAX_NUM_CHAN; // see cosim_defines.h

//------------------------------------------------------------------------------
void cosim_control(PLI_INT32 operation) {
#if defined(ncsim)||defined(verilogXL)
     switch (operation) {
     case vpiStop  : tf_dostop();   break; // cause $stop()
     case vpiFinish: tf_dofinish(); break; // cause $finish()
     default: vpi_printf("ERROR: %d for vpi_control() is not supported yet!\n", operation);
     }
#elif defined(modelsim)||defined(questasim)
     vpi_control(operation, 0);
#endif
//if (operation==vpiFinish) {
//    bfm_packet_t pkt;
//    pkt.cmd_type   = COSIM_CMD_TERM_REQ;
//    pkt.cmd_size   = 0;
//    pkt.cmd_length = 0;
//    pkt.cmd_ack    = COSIM_CMD_ACK_ERR;
//    pkt.attr       = 0;
//    pkt.addr       = 0;
//    int len = (int)sizeof(pkt);
//    int cid;
//    int dir;
//    for (cid=0; cid<m_cid_max; cid++) {
//        if (chn_handle(cid, &dir)!=(void*)(void*)-1L) {
//           if (dir==CHAN_HOST) {
//           if (chn_send(cid, len, (void*)&pkt)==len) {
//               chn_recv(cid, len, (void*)&pkt);
//               if (m_verbose>1) {
//                   vpi_printf("cosim_vpi_close cid=%d.\n", cid);
//               }
//           }
//           }
//        }
//    }
//}
}

//------------------------------------------------------------------------------
PLI_INT32   cosim_vpi_snd_Calltf   (PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_snd_Compiletf(PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_snd_Sizetf   (PLI_BYTE8 *user_data);

PLI_INT32   cosim_vpi_rcv_Calltf   (PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_rcv_Compiletf(PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_rcv_Sizetf   (PLI_BYTE8 *user_data);

PLI_INT32   cosim_vpi_set_verbose_Calltf   (PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_set_verbose_Compiletf(PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_set_verbose_Sizetf   (PLI_BYTE8 *user_data);

PLI_INT32   cosim_vpi_open_Calltf   (PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_open_Compiletf(PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_open_Sizetf   (PLI_BYTE8 *user_data);

PLI_INT32   cosim_vpi_close_Calltf   (PLI_BYTE8 *user_data); // called by $cosim_vpi_close()
PLI_INT32   cosim_vpi_close_Compiletf(PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_close_Callback (s_cb_data *callback_data); // called at the event of cbEndOfSimulation
PLI_INT32   cosim_vpi_close_Sizetf   (PLI_BYTE8 *user_data);

PLI_INT32   cosim_vpi_barrier_Calltf   (PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_barrier_Compiletf(PLI_BYTE8 *user_data);
PLI_INT32   cosim_vpi_barrier_Sizetf   (PLI_BYTE8 *user_data);

//------------------------------------------------------------------------------
void cosim_vpi_register() {
    s_vpi_systf_data tf_data;
    s_cb_data        cb_data_s;
    vpiHandle        callback_handle;

    tf_data.type        = vpiSysFunc;
    tf_data.sysfunctype = vpiSizedFunc;
    tf_data.tfname      = "$cosim_vpi_snd";
    tf_data.calltf      = cosim_vpi_snd_Calltf;
    tf_data.compiletf   = cosim_vpi_snd_Compiletf;
    tf_data.sizetf      = cosim_vpi_snd_Sizetf;
    tf_data.user_data   = NULL;
    vpi_register_systf(&tf_data);

    tf_data.type        = vpiSysFunc;
    tf_data.sysfunctype = vpiSizedFunc;
    tf_data.tfname      = "$cosim_vpi_rcv";
    tf_data.calltf      = cosim_vpi_rcv_Calltf;
    tf_data.compiletf   = cosim_vpi_rcv_Compiletf;
    tf_data.sizetf      = cosim_vpi_rcv_Sizetf;
    tf_data.user_data   = NULL;
    vpi_register_systf(&tf_data);

    tf_data.type        = vpiSysFunc;
    tf_data.sysfunctype = vpiSizedFunc; //vpiSysFuncSized;
    tf_data.tfname      = "$cosim_vpi_set_verbose";
    tf_data.calltf      = cosim_vpi_set_verbose_Calltf;
    tf_data.compiletf   = cosim_vpi_set_verbose_Compiletf;
    tf_data.sizetf      = cosim_vpi_set_verbose_Sizetf;
    tf_data.user_data   = NULL;
    vpi_register_systf(&tf_data);

    tf_data.type        = vpiSysFunc;
    tf_data.sysfunctype = vpiSizedFunc;
    tf_data.tfname      = "$cosim_vpi_open";
    tf_data.calltf      = cosim_vpi_open_Calltf;
    tf_data.compiletf   = cosim_vpi_open_Compiletf;
    tf_data.sizetf      = cosim_vpi_open_Sizetf;
    tf_data.user_data   = NULL;
    vpi_register_systf(&tf_data);

    tf_data.type        = vpiSysFunc;
    tf_data.sysfunctype = vpiSizedFunc;
    tf_data.tfname      = "$cosim_vpi_close";
    tf_data.calltf      = cosim_vpi_close_Calltf;
    tf_data.compiletf   = cosim_vpi_close_Compiletf;
    tf_data.sizetf      = cosim_vpi_close_Sizetf;
    tf_data.user_data   = NULL;
    vpi_register_systf(&tf_data);

    tf_data.type        = vpiSysFunc;
    tf_data.sysfunctype = vpiSizedFunc;
    tf_data.tfname      = "$cosim_vpi_barrier";
    tf_data.calltf      = cosim_vpi_barrier_Calltf;
    tf_data.compiletf   = cosim_vpi_barrier_Compiletf;
    tf_data.sizetf      = cosim_vpi_barrier_Sizetf;
    tf_data.user_data   = NULL;
    vpi_register_systf(&tf_data);

    cb_data_s.reason    = cbEndOfSimulation;
    cb_data_s.cb_rtn    = cosim_vpi_close_Callback;
    cb_data_s.obj       = NULL;
    cb_data_s.time      = NULL;
    cb_data_s.value     = NULL;
    cb_data_s.user_data = NULL;
    callback_handle     = vpi_register_cb(&cb_data_s);
    //vpi_free_object(callback_handle);
}

//------------------------------------------------------------------------------
// Barrier on the chanel id
// $cosim_vpi_barrier;   ==> $cosim_vpi_barrier(0);
// $cosim_vpi_barrier(); ==> $cosim_vpi_barrier(0);
// $cosim_vpi_barrier(cid);
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_barrier_Calltf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator;
  vpiHandle cidH;
  s_vpi_value value;
  int cid;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) {
      cid = 0;
  } else {
      cidH         = vpi_scan(arg_iterator); // chan_id
      value.format = vpiIntVal;
      vpi_get_value(cidH, &value);
      cid = (int)value.value.integer;
      vpi_free_object(arg_iterator);
  }

  if ((cid<0)||(cid>=m_cid_max)) {
       vpi_printf("ERROR: $cosim_vpi_barrier error: unknown channel id: %d\n", cid);
       value.format = vpiIntVal;
       value.value.integer = -1;
       vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
       return(-1);
     //cosim_control(vpiStop);
  }
//if (chn_handle(cid, 0)==(void*)-1L) {
//     vpi_printf("ERROR: $cosim_vpi_barrier error: channel id not opened yet: %d\n", cid);
//     cosim_control(vpiStop);
//}
//
//if (m_verbose>0) {
//    vpi_printf("[proc:%ld] barrier a ipc of cid=%d\n",
//                (long)getpid(), cid); vpi_flush();
//}
//if (chn_barrier(cid)<0) {
//     vpi_printf("ERROR: $cosim_vpi_barrier error: channel id: %d %s\n", cid, chn_error_msg(cid, 0));
//     cosim_control(vpiStop);
//}
  value.format = vpiIntVal;
  value.value.integer = 0;
  vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);

  if (m_verbose>0) {
      vpi_printf("[proc:%ld] barrier cid=%d\n", (long)getpid(), cid);
      vpi_flush();
  }
  return(0);
}

//------------------------------------------------------------------------------
// $cosim_vpi_barrier(channel_id);
PLI_INT32 cosim_vpi_barrier_Compiletf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     return(0);
  }
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_barrier must have only one argument.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_barrier must have integer argument, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  arg_handle = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: $cosim_vpi_barrier must have one arguments.\n");
       cosim_control(vpiFinish);
  }
  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_barrier_Sizetf(PLI_BYTE8 *user_data) {
  return(32); /* $cosim_vpi_barrier() returns 32-bit */
}

//------------------------------------------------------------------------------
// create and open IPC channel for HDL side for BFM (open IPC as CHAN_TARGET)
// $cosim_vpi_open;   ==> $cosim_vpi_open(0, 0x2300);
// $cosim_vpi_open(); ==> $cosim_vpi_open(0, 8960);
// $cosim_vpi_open(cid); ==> $cosim_vpi_open(cid, 8960);
// $cosim_vpi_open(cid, port);
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_open_Calltf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator;
  vpiHandle cidH, portH;
  s_vpi_value value;
  int cid, port;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) {
      cid = 0;
      port = 0x2300;
  } else {
      cidH         = vpi_scan(arg_iterator); // chan_id
      value.format = vpiIntVal;
      vpi_get_value(cidH, &value);
      cid   = (int)value.value.integer;
      portH = vpi_scan(arg_iterator);
      if (portH==NULL) {
          port = 0x2300;
      } else {
          vpi_get_value(portH, &value);
          port = (int)value.value.integer;
      }
      vpi_free_object(arg_iterator);
  }

  if ((cid<0)||(cid>=m_cid_max)) {
       vpi_printf("ERROR: $cosim_vpi_open error: unknown channel id: %d\n", cid);
       value.format = vpiIntVal;
       value.value.integer = -1;
       vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
       return(-1);
     //cosim_control(vpiStop);
  }
//if (chn_handle(cid, 0)!=(void*)-1L) {
//     vpi_printf("ERROR: $cosim_vpi_open error: channel id in use: %d\n", cid);
//     cosim_control(vpiStop);
//}

#define TIMEOUT 0x10000
  int ret=0;
  int timeout=0;

  do { ret = cosim_open_client( cid, port );
       timeout++;
  } while ((ret!=0)&&(timeout<TIMEOUT));
  if ((ret!=0)||(timeout>=TIMEOUT)) {
      vpi_printf("ERROR: $cosim_vpi_open error time out: %d\n", cid);
      value.format = vpiIntVal;
      value.value.integer = -1;
      vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
      return(-1);
  }

  value.format = vpiIntVal;
  value.value.integer = 0;
  vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);

  if (m_verbose>0) {
      vpi_printf("[proc:%ld] connected cid=%u port=%u\n", (long)getpid(), cid, port);
      vpi_flush();
  }
  return(0);
}

//------------------------------------------------------------------------------
// $cosim_vpi_open(channel_id, port);
PLI_INT32 cosim_vpi_open_Compiletf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     return(0);
  }
  // check 1st argument
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       return(0);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_open must have integer argument, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // check 2nd argument
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       return(0);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_open must have integer argument, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // check 3rd argument
  arg_handle = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: $cosim_vpi_open must have zero/one/two arguments.\n");
       cosim_control(vpiFinish);
  }
  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_open_Sizetf(PLI_BYTE8 *user_data) {
  return(32); /* $cosim_vpi_open() returns 32-bit */
}

//------------------------------------------------------------------------------
// close IPC channel
// $cosim_vpi_close; ==> $cosim_vpi_close(0);
// $cosim_vpi_close(); ==> $cosim_vpi_close(0);
// $cosim_vpi_close(cid);
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_close_Calltf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator;
  vpiHandle cidH;
  s_vpi_value value;
  int cid;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) {
      cid = 0;
  } else {
    cidH         = vpi_scan(arg_iterator); // chan_id
    value.format = vpiIntVal;
    vpi_get_value(cidH, &value);
    cid = (int)value.value.integer;
    vpi_free_object(arg_iterator);
  }

  if ((cid<0)||(cid>=m_cid_max)) {
       vpi_printf("ERROR: $cosim_vpi_close error: unknown channel id: %d\n", cid);
       value.format = vpiIntVal;
       value.value.integer = -1;
       vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
       return(-1);
     //cosim_control(vpiStop);
  }

  cosim_close(cid);

  if (m_verbose>0) {
      vpi_printf("cosim_vpi_closing cid=%d.\n", cid);
  }

  value.format = vpiIntVal;
  value.value.integer = 0;
  vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);

  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_close_Compiletf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     return(0);
  }
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_close must have only one argument if any.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  #if !defined(iverilog)
  if (tfarg_type==vpiOperation) {
     if (vpiNullOp!=vpi_get(vpiOpType,arg_handle)) {
        // deal with empty ()
        vpi_printf("ERROR: $cosim_vpi_close must have only one argument if any.\n");
        cosim_control(vpiFinish);
     }
  } else {
     if ((tfarg_type!=vpiIntegerVar)&&
         (tfarg_type!=vpiParameter)&&
         (tfarg_type!=vpiReg)&&
         (tfarg_type!=vpiConstant)) {
          vpi_printf("ERROR: $cosim_vpi_close must have integer argument, but %d.\n",
                      tfarg_type);
          vpi_free_object(arg_iterator);
          cosim_control(vpiFinish);
     }
  }
  #endif
  arg_handle = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: $cosim_vpi_close must have one arguments.\n");
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  return(0);
}

//------------------------------------------------------------------------------
// It will be called at the end of simulation by default.
// So, it cannot have argument.
PLI_INT32 cosim_vpi_close_Callback(s_cb_data *callback_data) {
  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_close_Sizetf(PLI_BYTE8 *user_data) {
  return(32); /* $cosim_vpi_close() returns 32-bit */
}

//------------------------------------------------------------------------------
// It returns how many bytes are sent.
//
// $cosim_vpi_snd(cid     // channel id
//               ,payload // data buffer
//               ,bnum    // num of bytes in 'payload[]'
//               );
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_snd_Calltf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator;
  vpiHandle cidH, bnuH, datH;
  s_vpi_value value;
  int    cid;
  int    n;
  uint32_t bnum;
  uint8_t buff[COSIM_DATA_BNUM];

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  cidH         = vpi_scan(arg_iterator);
  datH         = vpi_scan(arg_iterator);
  bnuH         = vpi_scan(arg_iterator);
  vpi_free_object(arg_iterator);

  value.format = vpiIntVal;
  vpi_get_value(cidH,  &value); cid  = (int)value.value.integer;
  vpi_get_value(bnuH,  &value); bnum = (unsigned int)value.value.integer;

  n = vpi_get(vpiSize, datH);
  if (bnum>COSIM_DATA_BNUM) {
     vpi_printf("ERROR: $cosim_vpi_snd data size exceeds.\n");
     cosim_control(vpiFinish);
     return(0);
  }
  if (n<bnum) { // num of bytes to move
     vpi_printf("ERROR: $cosim_vpi_snd data element.\n");
     cosim_control(vpiFinish);
     return(0);
  }
  for (n=0; n<bnum; n++) {
       vpiHandle eleH = vpi_handle_by_index(datH, n);
       if (eleH==NULL) {
           vpi_printf("ERROR: $cosim_vpi_snd data element: %d\n", n);
           cosim_control(vpiFinish);
           return(0);
       }
       value.format = vpiIntVal;
       vpi_get_value(eleH, &value);
       buff[n] = (value.value.integer&0xFF);
  }

  if (cosim_snd(cid, (char*)buff, bnum)!=bnum) {
      s_vpi_time time;
      time.type = vpiScaledRealTime;
      vpi_get_time(NULL, &time);
      vpi_printf("ERROR: something wrong while snd packet...\n");
      value.format = vpiIntVal;
      value.value.integer = -1;
      vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
      cosim_control(vpiStop);
      return(-1);
  } else {
    value.format = vpiIntVal;
    value.value.integer = (PLI_UINT32)bnum;
    vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
  }

  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_snd_Compiletf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;
  int n;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     vpi_printf("ERROR: $cosim_vpi_snd must have 3 arguments.\n");
     cosim_control(vpiFinish);
     return(0);
  }
  // cid
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_snd must have 3 arguments.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_put must have integer argument for 1-st, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // data[]
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_snd must have 3 arguments.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiArray)&&    // 28
      (tfarg_type!=vpiMemory)) {  // 29
       vpi_printf("ERROR: $cosim_vpi_snd must have array/memory argument of 2-nd, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // bnum, i.e., size
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_snd must have 3 arguments.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_put must have integer argument for 3-rd, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // check for extra
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: $cosim_vpi_snd must have 8 arguments.\n");
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_snd_Sizetf(PLI_BYTE8 *user_data) {
  return(32); /* $cosim_vpi_snd() returns 32-bit */
}

//------------------------------------------------------------------------------
// It tries to get data.
// It return num of bytes received.
// $cosim_vpi_rcv(cid      // channel id
//               ,payload  // array
//               ,bnum     // num of bytes received
//               );
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_rcv_Calltf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator;
  vpiHandle cidH, bnuH, datH;
  s_vpi_value value;
  int    idx;
  int    cid;
  uint32_t    size, bnum;
  uint8_t buff[COSIM_DATA_BNUM];

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  cidH         = vpi_scan(arg_iterator);
  datH         = vpi_scan(arg_iterator);
  bnuH         = vpi_scan(arg_iterator);
  vpi_free_object(arg_iterator);

  value.format = vpiIntVal;
  vpi_get_value(cidH, &value);
  cid = (int)value.value.integer;
  value.format = vpiIntVal;
  vpi_get_value(bnuH, &value);
  size = (int)value.value.integer;

  bnum = cosim_rcv(cid, (char*)buff, size);
  if (bnum<0) {
      vpi_printf("ERROR: $cosim_vpi_rcv data element.\n");
      cosim_control(vpiFinish);
      return(0);
  }
  for (idx=0; idx<bnum; idx++) {
       vpiHandle eleH = vpi_handle_by_index(datH, idx);
       if (eleH==NULL) {
           vpi_printf("ERROR: $cosim_vpi_rcv data element: %d\n", idx);
           cosim_control(vpiFinish);
           return(0);
       }
       value.format = vpiIntVal;
       value.value.integer = (PLI_UINT32)(buff[idx]);
       vpi_put_value(eleH, &value, NULL, vpiNoDelay);
  }

  value.format        = vpiIntVal;
  value.value.integer = (PLI_UINT32)bnum;
  vpi_put_value(bnuH, &value, NULL, vpiNoDelay);

  value.format = vpiIntVal;
  value.value.integer = (PLI_UINT32)bnum;
  vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);

  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_rcv_Compiletf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;
  int n;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     vpi_printf("ERROR: $cosim_vpi_rcv must have 3 arguments.\n");
     cosim_control(vpiFinish);
     return(0);
  }
  // cid
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_rcv must have 3 arguments.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_rcv must have integer argument of 1-st, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // data[]
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_rcv must have 3 arguments.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiArray)&&    // 28
      (tfarg_type!=vpiMemory)) {  // 29
       vpi_printf("ERROR: $cosim_vpi_rcv must have array/memory argument of 2-nd, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // bnum, i.e., size
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_rcv must have 3 arguments.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  if ((tfarg_type!=vpiIntegerVar)&&
      (tfarg_type!=vpiParameter)&&
      (tfarg_type!=vpiReg)&&
      (tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: $cosim_vpi_rcv must have integer argument of 3-rd, but %d.\n",
                   tfarg_type);
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  // check for extra
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: $cosim_vpi_rcv must have 3 arguments.\n");
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_rcv_Sizetf(PLI_BYTE8 *user_data) {
  return(32); /* $cosim_vpi_rcv() returns 32-bit */
}

//------------------------------------------------------------------------------
// $cosim_vpi_set_verbose; ==> $cosim_vpi_set_verbose(0);
// $cosim_vpi_set_verbose(); ==> $cosim_vpi_set_verbose(0);
// $cosim_vpi_set_verbose(n);
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_set_verbose_Calltf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_itr, arg1, arg2;
  s_vpi_value value;
  int level;
  PLI_INT32 result;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_itr      = vpi_iterate(vpiArgument, systf_handle);
  if (arg_itr==NULL) {
      level = 0;
  } else {
     arg1 = vpi_scan(arg_itr);
     #if !defined(iverilog)
     if (vpiOperation==vpi_get(vpiType,arg1)) {
         level = 0;
     } else {
         value.format = vpiIntVal;
         vpi_get_value(arg1, &value);
         level = value.value.integer;
     }
     #else
         value.format = vpiIntVal;
         vpi_get_value(arg1, &value);
         level = value.value.integer;
     #endif
     vpi_free_object(arg_itr);
  }
  cosim_set_verbose(level);
  m_verbose = level; 
  value.format = vpiIntVal;
  value.value.integer = 0;
  vpi_put_value(systf_handle, &value, NULL, vpiNoDelay);
  return(0);
}

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_set_verbose_Compiletf(PLI_BYTE8 *user_data) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     return(0);
  }
  arg_handle   = vpi_scan(arg_iterator);
  if (arg_handle==NULL) {
       vpi_printf("ERROR: $cosim_vpi_set_verbose must have only one argument.\n");
       cosim_control(vpiFinish);
  }
  tfarg_type = vpi_get(vpiType, arg_handle);
  #if !defined(iverilog)
  if (tfarg_type==vpiOperation) {
     if (vpiNullOp!=vpi_get(vpiOpType,arg_handle)) {
        // deal with empty ()
        vpi_printf("ERROR: $cosim_vpi_set_verbose must have only one argument if any.\n");
        cosim_control(vpiFinish);
     }
  } else {
     if ((tfarg_type!=vpiIntegerVar)&&
         (tfarg_type!=vpiParameter)&&
         (tfarg_type!=vpiReg)&&
         (tfarg_type!=vpiConstant)) {
          vpi_printf("ERROR: $cosim_vpi_set_verbose must have integer argument, but %d.\n",
                      tfarg_type);
          vpi_free_object(arg_iterator);
          cosim_control(vpiFinish);
     }
  }
  #endif
  arg_handle = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: $cosim_vpi_set_verbose must have one arguments.\n");
       vpi_free_object(arg_iterator);
       cosim_control(vpiFinish);
  }
  return(0);
}
//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_set_verbose_Sizetf(PLI_BYTE8 *user_data) {
  return(32); /* $cosim_vpi_set_verbose() returns 32-bit */
}

//------------------------------------------------------------------------------
void (*vlog_startup_routines[])() = {
      cosim_vpi_register,
      0
};

//------------------------------------------------------------------------------
PLI_INT32 cosim_vpi_arg_num_check(int num, char* name) {
  vpiHandle systf_handle, arg_iterator, arg_handle;
  PLI_INT32 tfarg_type;
  int i;

  systf_handle = vpi_handle(vpiSysTfCall, NULL);
  arg_iterator = vpi_iterate(vpiArgument, systf_handle);
  if (arg_iterator==NULL) { /* no argument */
     vpi_printf("ERROR: %s must have %d arguments.\n", name, num);
     return(1);
  }
  for (i = 0; i<num; i++) {
    arg_handle = vpi_scan(arg_iterator);
    if (arg_handle==NULL) { /* no argument */
       vpi_printf("ERROR: %s must have %d arguments.(%d)\n", name, num, i+1);
       return(1);
    }
    tfarg_type = vpi_get(vpiType, arg_handle);
    if ((tfarg_type!=vpiIntegerVar)&&(tfarg_type!=vpiParameter)&&(tfarg_type!=vpiConstant)) {
       vpi_printf("ERROR: %s must have integer argument, but %d.(%d)\n",
                   name, tfarg_type, i+1);
       vpi_free_object(arg_iterator);
       return(1);
    }
  }
  arg_handle = vpi_scan(arg_iterator);
  if (arg_handle!=NULL) {
       vpi_printf("ERROR: %s must have %d arguments.\n", name, num);
       vpi_free_object(arg_iterator);
       return(1);
  }
  vpi_free_object(arg_iterator);
  return(0);
}
//------------------------------------------------------------------------------
// Revision history:
//
// 2021.07.01: Started by Ando Ki (andoki@gmail.com)
//------------------------------------------------------------------------------
