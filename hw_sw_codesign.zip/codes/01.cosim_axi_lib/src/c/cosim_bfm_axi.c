//----------------------------------------------------------------------------
// Copyright (c) 2022-2024 by Ando Ki.
// All rights are reserved by Ando Ki.
//----------------------------------------------------------------------------
// cosim_bfm_axi.c
//----------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <assert.h>
#include "cosim_bfm_axi.h"

#pragma pack(1)
typedef struct __attribute__((__packed__)) {
  uint16_t cmd ;
  uint16_t flag;
  uint32_t addr;
  uint32_t data; // data for axi-lite, addr for axi-mm
  uint8_t  burst;
  uint8_t  size;
  uint16_t leng;
} cosim_bfm_packet_t;
#pragma pack()

//----------------------------------------------------------------------------
int cosim_bfm_axi_open( int cid, int port )
{
    // C side should be server since it invokes earlier than HDL simulator.
    return cosim_open_server( cid, port );
}

//----------------------------------------------------------------------------
int cosim_bfm_axi_close( int cid )
{
    return cosim_close( cid );
}

//----------------------------------------------------------------------------
//  [REQ]                  [RESP]
//  +---+---+---+---+      +---+---+---+---+ 
//  | flag  | cmd   |      | flag  | cmd   | 
//  +---+---+---+---+      +---+---+---+---+ 
//  | addr          |      | addr          | 
//  +---+---+---+---+      +---+---+---+---+ 
//  | data          |      |data(dont'care)| 
//  +---+---+---+---+      +---+---+---+---+ 
int cosim_bfm_axi_lite_write( uint32_t addr, uint32_t data, int cid )
{
    cosim_bfm_packet_t pkt_req, pkt_rsp;
    pkt_req.cmd  = COSIM_CMD_WR_REQ;
    pkt_req.addr = addr;
    pkt_req.data = data;
    int size = sizeof(pkt_req);
    int sent = cosim_snd( cid, (uint8_t*)&pkt_req, size );
    int nbytes = cosim_rcv ( cid, (uint8_t*)&pkt_rsp, size);
    if (pkt_rsp.cmd==COSIM_CMD_WR_RSP_ACK) return 0;
    else return -1;
}

//----------------------------------------------------------------------------
//  [REQ]                  [RESP]
//  +---+---+---+---+      +---+---+---+---+ 
//  | flag  | cmd   |      | flag  | cmd   | 
//  +---+---+---+---+      +---+---+---+---+ 
//  | addr          |      | addr          | 
//  +---+---+---+---+      +---+---+---+---+ 
//  |data(dont'care)|      | data          | 
//  +---+---+---+---+      +---+---+---+---+ 
int cosim_bfm_axi_lite_read( uint32_t addr, uint32_t *data, int cid )
{
    cosim_bfm_packet_t pkt_req, pkt_rsp;
    pkt_req.cmd  = COSIM_CMD_RD_REQ;
    pkt_req.addr = addr;
    pkt_req.data = 0;
    int size = sizeof(pkt_req);
    int sent = cosim_snd( cid, (uint8_t*)&pkt_req, size );
    int nbytes = cosim_rcv ( cid, (uint8_t*)&pkt_rsp, size);
    if (pkt_rsp.cmd==COSIM_CMD_RD_RSP_ACK) {
        if (data!=NULL) *data = pkt_rsp.data;
        return 0;
    } else return -1;
}

//----------------------------------------------------------------------------
//  [REQ]                 [RESP]
//  +---+---+---+---+     +---+---+---+---+
//  | flag  | cmd   |     | flag  | cmd   |
//  +---+---+---+---+     +---+---+---+---+
//  | addr[31:0]    |     | addr[31:0]    |
//  +---+---+---+---+     +-------+-------+
//  | addr[63:32]   |     | addr[63:32]   |
//  +---+---+---+---+     +-------+-------+
//  |     L | S | M |     |     L | S | M | M: mode of address, S: size of access, L: length of burst
//  +---+---+---+---+     +---+---+---+---+
//  |   |   |   |   | data byte stream
//  +---+---+---+---+
//  |   |   |   |   |
//  +---+---+---+---+
//  |   |   |   |   |
//  +---+---+---+---+
//  |   |   |   |   |
//  +---+---+---+---+
// data[] = size*leng bytes
// size: num of bytes for a beat, e.g., 1=1byte, 2=2byte
// leng: length of burst, e.g., 1=1, 2=2
int cosim_bfm_axi_write( uint64_t addr
                       , uint8_t *data
                       , unsigned int size
                       , unsigned int leng
                       , int cid )
{
    char buff_tx[COSIM_DATA_BNUM];
    char buff_rx[COSIM_DATA_BNUM];

    if (COSIM_DATA_BNUM<(sizeof(cosim_bfm_packet_t)+leng)) {
        printf("%s() too long length.\n", __func__);
        return -1;
    }

    cosim_bfm_packet_t pkt_req;
    pkt_req.cmd   = COSIM_CMD_WR_MM_REQ;
    pkt_req.addr  = addr&0xFFFFFFFF;
    pkt_req.data  =(addr>>32)&0xFFFFFFFF;
    pkt_req.burst = COSIM_CMD_MM_BURST_INC;
    pkt_req.size  = size;
    pkt_req.leng  = leng;
    memcpy(&buff_tx[0], &pkt_req, sizeof(pkt_req));
    memcpy(&buff_tx[sizeof(pkt_req)], data, size*leng);

    int all_size = sizeof(pkt_req) + size*leng;
    int sent = cosim_snd( cid, (uint8_t*)buff_tx, all_size );
    int nbytes = cosim_rcv ( cid, (uint8_t*)buff_rx, sizeof(pkt_req));
    if (nbytes!=sizeof(pkt_req)) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return -1;
    }
    if (((cosim_bfm_packet_t*)buff_rx)->cmd==COSIM_CMD_WR_MM_RSP_ACK) return 0;
    else return -1;
}

//----------------------------------------------------------------------------
//  [REQ]                 [RESP]
//  +---+---+---+---+     +---+---+---+---+
//  | flag  | cmd   |     | flag  | cmd   |
//  +---+---+---+---+     +---+---+---+---+
//  | addr[31:0]    |     | addr[31:0]    |
//  +---+---+---+---+     +-------+-------+
//  | addr[63:32]   |     | addr[63:32]   |
//  +---+---+---+---+     +-------+-------+
//  |     L | S | M |     |     L | S | M | M: mode of address, S: size of access, L: length of burst
//  +---+---+---+---+     +---+---+---+---+
//                        |   |   |   |   | data byte stream
//                        +---+---+---+---+
//                        |   |   |   |   |
//                        +---+---+---+---+
//                        |   |   |   |   |
//                        +---+---+---+---+
//                        |   |   |   |   |
//                        +---+---+---+---+
int cosim_bfm_axi_read( uint64_t addr
                      , uint8_t *data
                      , unsigned int size
                      , unsigned int leng
                      , int cid )
{
    char buff_rx[COSIM_DATA_BNUM];

    if (COSIM_DATA_BNUM<(sizeof(cosim_bfm_packet_t)+leng)) {
        printf("%s() too long length.\n", __func__);
        return -1;
    }

    cosim_bfm_packet_t pkt_req;
    pkt_req.cmd  = COSIM_CMD_RD_MM_REQ;
    pkt_req.addr  = addr&0xFFFFFFFF;
    pkt_req.data  =(addr>>32)&0xFFFFFFFF;
    pkt_req.burst = COSIM_CMD_MM_BURST_INC;
    pkt_req.size  = size;
    pkt_req.leng  = leng;

    int sent = cosim_snd( cid, (uint8_t*)&pkt_req, sizeof(pkt_req) );
    int all_size = sizeof(pkt_req)+size*leng;
    int nbytes = cosim_rcv ( cid, (uint8_t*)buff_rx, all_size);
    if (nbytes!=all_size) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return -1;
    }
    if (((cosim_bfm_packet_t*)buff_rx)->cmd==COSIM_CMD_RD_MM_RSP_ACK) {
        if (data!=NULL) memcpy(data, &buff_rx[sizeof(pkt_req)], size*leng);
        return 0;
    } else return -1;
}

//----------------------------------------------------------------------------
// Returns the number of bits of data, user port of BFM AXI-MM.
// Returns the mode of BFM.
//         3'b001:axi-lite 3'b010:axi-stream, 3'b100:axi-mm, 3'b111: all
int cosim_bfm_axi_mm_get_config( unsigned int *data_width // bits
                               , unsigned int *addr_width // bits
                               , unsigned int *mode
                               , int  cid )
{
    #define SIZE_ALL COSIM_DATA_BNUM
    char buff_tx[COSIM_DATA_BNUM];
    char buff_rx[COSIM_DATA_BNUM];

    *(uint16_t*)&buff_tx[0] = COSIM_CMD_CONFIG_MM_REQ;
    *(uint16_t*)&buff_tx[2] = 0;
    *(uint16_t*)&buff_tx[4] = 0;
    *(uint16_t*)&buff_tx[6] = 0;
    int num_send = COSIM_CMD_SIZE;
  //int num_sent = cosim_snd( cid, (uint8_t*)&buff_tx, num_send );
    int num_sent = cosim_snd( cid, (uint8_t*)buff_tx, num_send );
    if (num_sent!=num_send) {
        printf("%s() cosim_snd() data num mis-match.\n", __func__);
        return (num_send<0) ? num_sent : -1;
    }
  //int num_rcv  = cosim_rcv( cid, (uint8_t*)&buff_rx, SIZE_ALL);
    int num_rcv  = cosim_rcv( cid, (uint8_t*)buff_rx, SIZE_ALL);
    if (num_rcv<0) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return num_rcv;
    }
    uint16_t resp_cmd = *(uint16_t*)&buff_rx[0];
    uint16_t resp_mode = *(uint16_t*)&buff_rx[2];
    uint16_t resp_data_width = *(uint16_t*)&buff_rx[4];
    uint16_t resp_addr_width = *(uint16_t*)&buff_rx[6];
    if (resp_cmd!=COSIM_CMD_CONFIG_MM_RSP_ACK) {
        printf("%s() NACK\n", __func__);
        return -1;
    }
    if (data_width!=NULL) *data_width = (unsigned int)resp_data_width;
    if (addr_width!=NULL) *addr_width = (unsigned int)resp_addr_width;
    if (mode!=NULL)       *mode       = (unsigned int)resp_mode;

    return 0;
}

//----------------------------------------------------------------------------
//  [REQ]                  [RESP]
//  +---+---+---+---+      +---+---+---+---+
//  | flag  | cmd   |      | flag  | cmd   |
//  +---+---+---+---+      +---+---+---+---+
//  | sizeU | sizeD |      | sizeU | sizeD |
//  +---+---+---+---+ --   +-------+-------+
//  |   |   |   |   |  ^
//  +---+---+---+---+  |
//  |   |   |   |   |  | data byte stream (size_data)
//  +---+---+---+---+  |
//  |   |   |   |   |  v
//  +---+---+---+---+ --
//  |   |   |   |   |  ^
//  +---+---+---+---+  | user byte stream (size_user)
//  |   |   |   |   |  v
//  +---+---+---+---+ --
// * data must be a multiple of bytes.
// * user can be any bit-width, but the packet must be byte-aligned,
//   --> 2-bit will be 8-bit (a byte) packed.
int cosim_bfm_axi_stream_h2c( uint8_t       *buff_data // byte stream
                            , unsigned int   size_data // num of bytes
                            , uint8_t       *buff_user // byte stream
                            , unsigned int   size_user // num of bytes
                            , unsigned int   last
                            , int   cid )
{
    #define SIZE_ALL COSIM_DATA_BNUM
    char buff_tx[COSIM_DATA_BNUM];
    char buff_rx[COSIM_DATA_BNUM];

    *(uint16_t*)&buff_tx[0] = COSIM_CMD_H2C_REQ;
    *(uint16_t*)&buff_tx[2] = (last&0x1)<<1;
    *(uint16_t*)&buff_tx[4] = size_data;
    *(uint16_t*)&buff_tx[6] = size_user;
    memcpy(&buff_tx[COSIM_CMD_SIZE], buff_data, size_data);
    memcpy(&buff_tx[COSIM_CMD_SIZE+size_data], buff_user, size_user);
//for (int idx=COSIM_CMD_SIZE+size_data; idx<(COSIM_CMD_SIZE+size_data+size_user); idx++) {
//printf("%s() buff_tx[%d]=0x%02X\n", __func__, idx, buff_tx[idx]);
//}

    int num_send = COSIM_CMD_SIZE+size_data+size_user;
  //int num_sent = cosim_snd( cid, (uint8_t*)&buff_tx, num_send );
    int num_sent = cosim_snd( cid, (uint8_t*)buff_tx, num_send );
    if (num_sent!=num_send) {
        printf("%s() cosim_snd() data num mis-match.\n", __func__);
        return (num_send<0) ? num_sent : -1;
    }

  //int num_rcv  = cosim_rcv( cid, (uint8_t*)&buff_rx, 64); // more than 8
    int num_rcv  = cosim_rcv( cid, (uint8_t*)buff_rx, 64); // more than 8
    if (num_rcv<0) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return num_rcv;
    }
    uint16_t resp_cmd = *(uint16_t*)&buff_rx[0];
    uint16_t resp_size_data = *(uint16_t*)&buff_rx[4];
    uint16_t resp_size_user = *(uint16_t*)&buff_rx[6];
    if (resp_cmd!=COSIM_CMD_H2C_RSP_ACK) {
        printf("%s() NACK\n", __func__);
        return -1;
    }
    if (resp_size_data!=size_data) { // not necessary condition
        printf("%s() Mis-match data size: %d:%d\n", __func__, resp_size_data, size_data);
    }
    if (resp_size_user!=size_user) { // not necessary condition
        printf("%s() Mis-match user data size: %d:%d\n", __func__, resp_size_user, size_user);
    }

    return 0;
}

//----------------------------------------------------------------------------
//  [REQ]                  [RESP]
//  +---+---+---+---+      +---+---+---+---+
//  | flag  | cmd   |      | flag  | cmd   |
//  +---+---+---+---+      +---+---+---+---+
//  | sizeU | sizeD |      | sizeU | sizeD |
//  +---+---+---+---+      +-------+-------+ --
//                         |   |   |   |   |  ^
//                         +---+---+---+---+  |
//                         |   |   |   |   |  | data byte stream (size_data)
//                         +---+---+---+---+  |
//                         |   |   |   |   |  v
//                         +---+---+---+---+ --
//                         |   |   |   |   |  ^
//                         +---+---+---+---+  | user byte stream (size_user)
//                         |   |   |   |   |  v
//                         +---+---+---+---+ --
// size_data: gives a hint to get the number of bytes when call,
//            returns the number of bytes actually poped.
//            it tries to get data until last or the number of bytes.
//            user whole when it is 0.
int cosim_bfm_axi_stream_c2h( uint8_t       *buff_data // byte stream
                            , unsigned int   size_data // num of bytes
                            , uint8_t       *buff_user // byte stream
                            , unsigned int   size_user // num of bytes
                            , unsigned int  *last
                            , int   cid )
{
    #define SIZE_ALL COSIM_DATA_BNUM
    char buff_tx[COSIM_DATA_BNUM];
    char buff_rx[COSIM_DATA_BNUM]; // to get user data


    *(uint16_t*)&buff_tx[0] = COSIM_CMD_C2H_REQ;
    *(uint16_t*)&buff_tx[2] = 0;
    *(uint16_t*)&buff_tx[4] = (uint16_t)size_data;
    *(uint16_t*)&buff_tx[6] = (uint16_t)size_user;

    int num_send = COSIM_CMD_SIZE;
    int num_sent = cosim_snd( cid, (uint8_t*)&buff_tx, num_send );
    if (num_sent!=num_send) {
        printf("%s() cosim_snd() data num mis-match.\n", __func__);
        return (num_send<0) ? num_sent : -1;
    }
    int num_rcv  = cosim_rcv( cid, (uint8_t*)&buff_rx, SIZE_ALL);
    if (num_rcv<0) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return num_rcv;
    }
    uint16_t resp_cmd  = *(uint16_t*)&buff_rx[0];
    uint16_t resp_flag = *(uint16_t*)&buff_rx[2];
    uint16_t resp_size_data = *(uint16_t*)&buff_rx[4];
    uint16_t resp_size_user = *(uint16_t*)&buff_rx[6];
    if (resp_cmd!=COSIM_CMD_C2H_RSP_ACK) {
        printf("%s() NACK\n", __func__);
        return -1;
    }
    if (last!=NULL) *last = (resp_flag&0x2)>>1;

    memcpy(buff_data, &buff_rx[COSIM_CMD_SIZE], resp_size_data);
    memcpy(buff_user, &buff_rx[COSIM_CMD_SIZE+resp_size_data], resp_size_user);

    return 0;
}

//----------------------------------------------------------------------------
// Returns the number of bits of data, user port of BFM AXI-Stream.
// Returns the mode of BFM.
//         3'b001:axi-lite 3'b010:axi-stream, 3'b100:axi-mm, 3'b111: all
int cosim_bfm_axi_stream_get_config( unsigned int *data_width // bits
                                   , unsigned int *user_width // bits
                                   , unsigned int *mode
                                   , int  cid )
{
    #define SIZE_ALL COSIM_DATA_BNUM
    char buff_tx[COSIM_DATA_BNUM];
    char buff_rx[COSIM_DATA_BNUM];

    *(uint16_t*)&buff_tx[0] = COSIM_CMD_CONFIG_REQ;
    *(uint16_t*)&buff_tx[2] = 0;
    *(uint16_t*)&buff_tx[4] = 0;
    *(uint16_t*)&buff_tx[6] = 0;
    int num_send = COSIM_CMD_SIZE;
    int num_sent = cosim_snd( cid, (uint8_t*)&buff_tx, num_send );
    if (num_sent!=num_send) {
        printf("%s() cosim_snd() data num mis-match.\n", __func__);
        return (num_send<0) ? num_sent : -1;
    }
    int num_rcv  = cosim_rcv( cid, (uint8_t*)&buff_rx, SIZE_ALL);
    if (num_rcv<0) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return num_rcv;
    }
    uint16_t resp_cmd = *(uint16_t*)&buff_rx[0];
    uint16_t resp_mode = *(uint16_t*)&buff_rx[2];
    uint16_t resp_data_width = *(uint16_t*)&buff_rx[4];
    uint16_t resp_user_width = *(uint16_t*)&buff_rx[6];
    if (resp_cmd!=COSIM_CMD_CONFIG_RSP_ACK) {
        printf("%s() NACK\n", __func__);
        return -1;
    }
    if (data_width!=NULL) *data_width = (unsigned int)resp_data_width;
    if (user_width!=NULL) *user_width = (unsigned int)resp_user_width;
    if (mode!=NULL)       *mode       = (unsigned int)resp_mode;

    return 0;
}

//----------------------------------------------------------------------------
// finish simulation, but communication channel remains
int cosim_bfm_axi_finish( int cid )
{
    #define SIZE_ALL COSIM_DATA_BNUM
    char buff_tx[COSIM_DATA_BNUM];
    char buff_rx[COSIM_DATA_BNUM];

    *(uint16_t*)&buff_tx[0] = COSIM_CMD_TERM_REQ;
    *(uint16_t*)&buff_tx[2] = 0;
    *(uint16_t*)&buff_tx[4] = 0;
    *(uint16_t*)&buff_tx[6] = 0;
    int num_send = COSIM_CMD_SIZE;
    int num_sent = cosim_snd( cid, (uint8_t*)&buff_tx, num_send );
    if (num_sent!=num_send) {
        printf("%s() cosim_snd() data num mis-match.\n", __func__);
        return (num_send<0) ? num_sent : -1;
    }
    int num_rcv  = cosim_rcv( cid, (uint8_t*)&buff_rx, SIZE_ALL);
    if (num_rcv<0) {
        printf("%s() cosim_rcv() data num mis-match.\n", __func__);
        return num_rcv;
    }
    uint16_t resp_cmd = *(uint16_t*)&buff_rx[0];
    if (resp_cmd!=COSIM_CMD_TERM_RSP_ACK) {
        printf("%s() NACK\n", __func__);
        return -1;
    }

    return 0;
}

//----------------------------------------------------------------------------
// Revision history
//
// 2024.07.27: data type changed
// 2024.07.27: 64-bit address is used for cosim_bfm_axi_read()/write()
// 2023.03.03: Doxygen comment added.
// 2022.07.01: Started by Ando Ki (andoki@gmail.com)
//----------------------------------------------------------------------------
