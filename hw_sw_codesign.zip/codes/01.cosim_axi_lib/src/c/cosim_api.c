//------------------------------------------------------------------------------
// Copyright (c) 2021 by Ando Ki.
// All rights reserved by Ando Ki.
//------------------------------------------------------------------------------
// cosim_api.c
//------------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cosim_socket.h"
#include "cosim_defines.h"
#include "cosim_header.h"
#include "cosim_api.h"

#if defined(DEBUG)||defined(RIGOR)
#define PRINTF(format, ...)\
    do { if (m_verbose>0) {\
             printf("%s(): " format, __func__, ##__VA_ARGS__);\
             fflush(stdout); }} while (0)
#else
#define PRINTF(...) do { } while (0)
#endif

#define USE_NONBLOCKING  0 // 0 means blocking mode

// not re-enterant
static int   m_verbose=0;
static int   m_initialized=0;
static       CosimSocketHandle_t m_handle[COSIM_MAX_NUM_CHAN];

//------------------------------------------------------------------------------
static void cosim_cleanup( void )
{
    for (int i=0; i<COSIM_MAX_NUM_CHAN; i++) {
        if (m_handle[i]!=NULL) {
            socket_release(m_handle[i]);
            m_handle[i] = NULL;
        }
    }
}


//------------------------------------------------------------------------------
// cid:
// type: type of operation, 
//       COSIM_SOCKET_TYPE_SERVER=1
//       COSIM_SOCKET_TYPE_CLIENT=2
// port: socket port
int cosim_open( int   cid
              , int   type
              , int   server_port
              , char *server_ip ) // valid when type is CLIENT
{
    if (m_initialized==0) {
        for (int i=0; i<COSIM_MAX_NUM_CHAN; i++) {
            m_handle[i] = NULL;
        }
        m_initialized = 1;
    }
    if ((cid<0)||(cid>COSIM_MAX_NUM_CHAN)) return -1;
    if (m_handle[cid]!=NULL) {
        PRINTF("Warning already used.\n");
    }
    int nonblock = USE_NONBLOCKING;
    if (type==COSIM_SOCKET_TYPE_SERVER) {
        m_handle[cid] = socket_init_server( server_port
                                          , nonblock );
        PRINTF("INFO server port=0x%X\n", server_port);
    } else {
        m_handle[cid] = socket_init_client( server_port
                                          , server_ip
                                          , nonblock );
        PRINTF("INFO client to server port=0x%X ip=%s\n", server_port, server_ip);
    }
    if (m_handle[cid]==NULL) {
        PRINTF("Warning handler not OK. cid=%d\n", cid);
        return -1;
    }

    atexit(cosim_cleanup);

    return 0;
}

int cosim_open_server( int cid
                     , int port )
{
    return cosim_open( cid
                     , COSIM_SOCKET_TYPE_SERVER
                     , port
                     , NULL );
}

int cosim_open_client( int cid
                     , int server_port )
{
    return cosim_open( cid
                     , COSIM_SOCKET_TYPE_CLIENT
                     , server_port
                     , "127.0.0.1" );
}

//------------------------------------------------------------------------------
int cosim_close(int cid)
{
    if (m_handle[cid]!=NULL) {
        PRINTF("INFO closing %s cid=%d port=0x%X\n",
                (m_handle[cid]->type==1) ? "server" : "client",
                 cid, m_handle[cid]->port);
        socket_release(m_handle[cid]);
        m_handle[cid] = NULL;
    }
    return 0;
}

//------------------------------------------------------------------------------
int cosim_barrier(int cid)
{
    return 0;
}

//------------------------------------------------------------------------------
int cosim_set_verbose(int level)
{
    m_verbose = level;
    return 0;
}

//------------------------------------------------------------------------------
int cosim_get_verbose(void)
{
    return m_verbose;
}

//------------------------------------------------------------------------------
// It sends packet_header+payload and returns the number of byte of payload.
// It returns the number of bytes of payload.
int cosim_snd( int   cid     // IPC channel ID
             , char *payload // data buffer
             , int   size )  // number of bytes to send
{
    cosim_header_t pkt;
    pkt.id   = 0;
    pkt.cmd  = COSIM_CMD_DATA;
    pkt.ack  = 0;
    pkt.attr = 0;
    pkt.size = size;

    if (size==0) { // zero payload
        if (socket_write(m_handle[cid], (char*)&pkt, sizeof(pkt))!=sizeof(pkt)) {
            PRINTF("%s\n", "zero payload");
            return -1;
        }
        return 0;
    }

    // non-zero payload
    int pkt_size=sizeof(pkt);
    int bnum = size+pkt_size;
    if (bnum>COSIM_DATA_BNUM) {
        PRINTF("%s\n", "buffer size small");
        return -1;
    }
    char buff[COSIM_DATA_BNUM];
    memcpy((void*)buff, (void*)&pkt, pkt_size);
    memcpy((void*)(buff+pkt_size), (void*)payload, size);

    // note that socket_write uses header and payload
    if (socket_write(m_handle[cid], buff, bnum)!=bnum) {
        PRINTF("%s\n", "write error.");
        return -1;
    }
    return size; // payload size
}

//------------------------------------------------------------------------------
// It receives packet_header+payload and returns the number of byte of payload.
int cosim_rcv( int   cid     // IPC channel ID
             , char *payload // data buffer
             , int   size )  // size of payload in the number of bytes
{
    char buff[COSIM_DATA_BNUM];
    int len = socket_read(m_handle[cid], buff, COSIM_DATA_BNUM);
    if (len<0) {
        PRINTF("ERROR: something wrong while rcv packet\n");
        return -1;
    }

    cosim_header_t *pkt=(cosim_header_t*)buff;
    int pkt_size=sizeof(cosim_header_t);
    int nbytes = pkt->size;

    if (len<(nbytes+pkt_size)) {
        PRINTF("ERROR: something wrong while rcv packet\n");
        return -1;
    }

    if (size<nbytes) {
        PRINTF("ERROR: buffer not sufficent\n");
        return -1;
    }

    for (int i=0; i<nbytes; i++) {
         payload[i] = buff[i+pkt_size];
    }

    return nbytes; // payload size
}

#undef PRINTF
//------------------------------------------------------------------------------
// Revision history
//
// 2021.07.01: Started by Ando Ki (andoki@gmail.com)
//------------------------------------------------------------------------------
