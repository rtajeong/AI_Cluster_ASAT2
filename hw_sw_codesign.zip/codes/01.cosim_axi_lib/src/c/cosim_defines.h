#ifndef COSIM_DEFINES_H
#define COSIM_DEFINES_H
/**
 * @file cosim_defines.h
 *
 */
//------------------------------------------------------------------------------
// Copyright (c) 2022 by Ando Ki.
// All rights reserved by Ando Ki.
//------------------------------------------------------------------------------
// 'c/cosim_defines.h' and 'verilog/cosim_defines.vh'
//------------------------------------------------------------------------------
// for 'cmd_type' field
#define COSIM_CMD_NULL        0x00  // skip
#define COSIM_CMD_DATA        0x01
#define COSIM_CMD_TERM_REQ    0x08
#define COSIM_CMD_TERM_RSP    0x09

//------------------------------------------------------------------------------
// for 'cmd_ack' field
#define COSIM_CMD_ACK_ERR     0x0
#define COSIM_CMD_ACK_OK      0x1

//------------------------------------------------------------------------------
// for 'data[]' field
#define COSIM_DATA_BNUM      (4*1024)

//------------------------------------------------------------------------------
// maximum number of channels, i.e., sockets
#define COSIM_MAX_NUM_CHAN    8

//------------------------------------------------------------------------------
// command channels to control termination
#define COSIM_CHAN_ID         0

//------------------------------------------------------------------------------
// command channels to control termination
#define COSIM_PORT            0x2300

//------------------------------------------------------------------------------
// Revision history:
//
// 2022.11.18: Modified for generic cosim
// 2021.07.01: Started by Ando Ki (andoki@gmail.com)
//------------------------------------------------------------------------------
#endif // COSIM_DEFINES_H
