#pragma once
//----------------------------------------------------------------------------
// Copyright (c) 2022-2024 by Ando Ki.
// All rights are reserved by Ando Ki.
//----------------------------------------------------------------------------
#include "cosim_api.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "cosim_bfm_axi_defines.h"

/**
  * @brief Prepare cosimulation channel for SW side, i.e., host.
  *        It must be a server since HDL simulator takes time to be invoked.
  *
  * @param cid  Channel identification
  * @param port Socket port 
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_open( int cid, int port );

/**
  * @brief Close cosimulation channel.
  *
  * @param cid  Channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_close( int cid );

/**
  * @brief Generate AMBA AXI-Lite write transaction.
  *
  * @param addr  32-bit address to be referred
  * @param data  32-bit data to be written
  * @param cid   Cosim channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_lite_write( uint32_t addr
                            , uint32_t data // 4-byte
                            , int cid );

/**
  * @brief Generate AMBA AXI-Lite read transaction.
  *
  * @param addr  32-bit address to be referred
  * @param *data pointer to return 32-bit data
  * @param cid   Cosim channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_lite_read( uint32_t  addr
                           , uint32_t *data // 4-byte
                           , int  cid );

/**
  * @brief Generate an AMBA AXI write burst transaction.
  *        The burst consists of 'leng' of 'beat' and
  *        each 'beat' carries 'size' of bytes.
  *
  * @param addr  64-bit address to be referred
  *              lower 32-bit is used for 32-bit addressing
  * @param *data Pointer to buffer that containing data to be written,
  *              where the data is byte stream in little-endian fashion.
  * @param size  Number of bytes to form a beat of burst
  * @param leng  Number of beat for a burst
  * @param cid   Channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_write( uint64_t     addr
                       , uint8_t     *data // byte stream (little-endian)
                       , unsigned int size // num of bytes for a beat
                       , unsigned int leng // num of burst
                       , int cid );

/**
  * @brief Generate an AMBA AXI read burst transaction.
  *        The burst consists of 'leng' of 'beat' and
  *        each 'beat' carries 'size' of bytes.
  *
  * @param addr  64-bit address to be referred
  *              lower 32-bit is used for 32-bit addressing
  * @param *data Pointer to buffer that returns data has read,
  *              where the data is byte stream in little-endian fashion.
  * @param size  Number of bytes to form a beat of burst
  * @param leng  Number of beat for a burst
  * @param cid   Channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_read( uint64_t      addr
                      , uint8_t      *data // byte stream (little-endian)
                      , unsigned int  size // num of bytes for a beat
                      , unsigned int  leng // num of burst
                      , int cid );

/**
  * @brief Get BFM (Bus Functional Module) configuration.
  *
  * @param *data_width  Number of bits of data bus
  * @param *addr_width  Number of bits of address bus
  * @param *mode        Encoding code as follows,
  *                     3'b001: axi-lite, 3'b010: axi-stream, 3'b100: axi-mm
  * @param cid   Channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_mm_get_config( unsigned int *data_width // bits
                               , unsigned int *addr_width // bits
                               , unsigned int *mode
                               , int  cid );

/**
  * @brief Generate an AXI-Stream that goses from the host, i.e., BFM to bus
  *
  * @param *buff_data   Pointer to the buffer containing byte stream
  * @param  size_data   Number of bytes in the 'buff_data'
  * @param *buff_user   Pointer to the buffer containing user data stream.
  *                     When actual 'user' signal is n-bit width,
  *                     this buffer contains '((n+7)/8)*8' bytes for each strem transfer.
  *                     As a result, this buffer must contain
  *                     'size_data'/('data_width'/8)*((n+7)/8)*8 bytes.
  * @param  size_user   Number of bytes in the 'buffer_user' not actual user data
  * @param  last        Assert 'last' signal at the end of stream when it is 1,
  *                     otherwise the stream does not generate 'last' at the end of stream.
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_stream_h2c( uint8_t       *buff_data // byte stream
                            , unsigned int   size_data // num of bytes in buff_data
                            , uint8_t       *buff_user // byte stream
                            , unsigned int   size_user // num of bytes in buff_data
                            , unsigned int   last
                            , int   cid );

/**
  * @brief Generate an AXI-Stream that comes from the bus to the host, i.e., BFM
  *
  * @param *buff_data   Pointer to the buffer containing byte stream
  * @param  size_data   Number of bytes in the 'buff_data'
  * @param *buff_user   Pointer to the buffer containing user data stream.
  *                     When actual 'user' signal is n-bit width,
  *                     this buffer contains '((n+7)/8)*8' bytes for each strem transfer.
  *                     As a result, this buffer must contain
  *                     'size_data'/('data_width'/8)*((n+7)/8)*8 bytes.
  * @param  size_user   Number of bytes in the 'buffer_user' not actual user data
  * @param *last        It will be 1 when 'last' comes with the stream.
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_stream_c2h( uint8_t       *buff_data // byte stream
                            , unsigned int   size_data // num of bytes in buff_data
                            , uint8_t       *buff_user // byte stream
                            , unsigned int   size_user // num of bytes in buff_data
                            , unsigned int  *last
                            , int   cid );

/**
  * @brief Get BFM (Bus Functional Module) configuration.
  *
  * @param *data_width  Number of bits of stream data bus
  * @param *user_width  Number of bits of stream user bus
  * @param *mode        Encoding code as follows,
  *                     3'b001: axi-lite, 3'b010: axi-stream, 3'b100: axi-mm
  * @param cid   Channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_stream_get_config( unsigned int *data_width // bits
                                   , unsigned int *user_width // bits
                                   , unsigned int *mode
                                   , int  cid );

/**
  * @brief Finish simulation, but communication channel remains open.
  *
  * @param cid  Channel identification
  *
  * @return 0 on success, otherwise negative number on failure.
  */
int cosim_bfm_axi_finish( int cid );

#ifdef __cplusplus
}
#endif

//----------------------------------------------------------------------------
// Revision history
//
// 2024.08.20: 'extern "C" added
// 2024.07.27: data type changed
// 2024.07.27: 64-bit address is used for cosim_bfm_axi_read()/write()
// 2023.03.03: Doxygen comment added.
// 2022.07.01: Started by Ando Ki (andoki@gmail.com)
//----------------------------------------------------------------------------
