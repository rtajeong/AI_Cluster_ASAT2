#ifndef COSIM_BFM_AXI_DEFINES_H
#define COSIM_BFM_AXI_DEFINES_H
//------------------------------------------------------------------------------
// Copyright (c) 2022 by Ando Ki.
// All rights reserved by Ando Ki.
//------------------------------------------------------------------------------
// [AXI-lite Memory Map Access]
// +---+---+---+---+
// | flag  | cmd   |
// +---+---+---+---+
// | addr          |
// +---+---+---+---+
// | data          |
// +---+---+---+---+
//----------------------------------------------------------------------------
// [AXI-mm Memory Map Access]
// +---+---+---+---+
// | flag  | cmd   |
// +---+---+---+---+
// | addr          |
// +---+---+---+---+
// |     L | S | M | M: mode of address, S: size of access, L: length of burst
// +---+---+---+---+ 
// |   |   |   |   | data (byte-stream)
// +---+---+---+---+ 
// |   |   |   |   | data (byte-stream)
// +---+---+---+---+
// |   |   |   |   | data (byte-stream)
// +---+---+---+---+ 
// |   |   |   |   | data (byte-stream)
// +---+---+---+---+
//----------------------------------------------------------------------------
// [AXI-stream Access]
// +---+---+---+---+ --
// | flag  | cmd   |  | flag[0]=start, falg[1]=last
// +---+---+---+---+  |
// | sizeU | sizeD |  | (COSIM_CMD_SIZE=8)
// +---+---+---+---+ --     --
// |   |   |   |   | data    |
// +---+---+---+---+         | size_data
// |   |   |   |   | data    |
// +---+---+---+---+         |
// |   |   |   |   | data    |
// +---+---+---+---+        --
// |   |   |   |   | user    |
// +---+---+---+---+         | size_user
// |   |   |   |   | user    |
// +---+---+---+---+        --
//------------------------------------------------------------------------------
// 'cmd' field for AXI-lite memory map
#define COSIM_CMD_NULL              0x0000
#define COSIM_CMD_RD_REQ            0x0001
#define COSIM_CMD_WR_REQ            0x0002
#define COSIM_CMD_RD_RSP_ACK        0x1001
#define COSIM_CMD_RD_RSP_NACK       0x2001
#define COSIM_CMD_WR_RSP_ACK        0x1002
#define COSIM_CMD_WR_RSP_NACK       0x2002

// 'cmd' field for AXI-mm memory map
#define COSIM_CMD_RD_MM_REQ         0x0004
#define COSIM_CMD_WR_MM_REQ         0x0005
#define COSIM_CMD_RD_MM_RSP_ACK     0x1004
#define COSIM_CMD_RD_MM_RSP_NACK    0x2004
#define COSIM_CMD_WR_MM_RSP_ACK     0x1005
#define COSIM_CMD_WR_MM_RSP_NACK    0x2005
#define COSIM_CMD_CONFIG_MM_REQ        0x0006
#define COSIM_CMD_CONFIG_MM_RSP_ACK    0x1006
#define COSIM_CMD_CONFIG_MM_RSP_NACK   0x2006

// 'cmd' field for AXI-stream memory map
#define COSIM_CMD_H2C_REQ           0x000A
#define COSIM_CMD_C2H_REQ           0x000B
#define COSIM_CMD_H2C_RSP_ACK       0x100A
#define COSIM_CMD_H2C_RSP_NACK      0x200A
#define COSIM_CMD_C2H_RSP_ACK       0x100B
#define COSIM_CMD_C2H_RSP_NACK      0x200B
#define COSIM_CMD_CONFIG_REQ        0x000C
#define COSIM_CMD_CONFIG_RSP_ACK    0x100C
#define COSIM_CMD_CONFIG_RSP_NACK   0x200C

// 'cmd' field for simulation control
#define COSIM_CMD_TERM_REQ          0x0010
#define COSIM_CMD_TERM_RSP_ACK      0x1010
#define COSIM_CMD_TERM_RSP_NACK     0x2010

//------------------------------------------------------------------------------
// for 'cmd_ack' field
#define COSIM_CMD_ACK_ERR     0x0
#define COSIM_CMD_ACK_OK      0x1

//------------------------------------------------------------------------------
// for cmd_rd/wr_mm
#define COSIM_CMD_MM_BURST_FIXED 0
#define COSIM_CMD_MM_BURST_INC   1
#define COSIM_CMD_MM_BURST_WRAP  2

//------------------------------------------------------------------------------
// maximum number of channels, i.e., sockets
#define COSIM_MAX_NUM_CHAN    8

//------------------------------------------------------------------------------
// command channels to control termination
#define COSIM_CHAN_ID         0

//------------------------------------------------------------------------------
// command channels to control termination
#define COSIM_PORT            0x00002300

//------------------------------------------------------------------------------
// for 'data[]' field
#define COSIM_DATA_BNUM       (4*1024) // considering stream

//------------------------------------------------------------------------------
#define COSIM_CMD_SIZE         8

//------------------------------------------------------------------------------
// Revision history:
//
// 2022.10.01: Started by Ando Ki (andoki@gmail.com)
//------------------------------------------------------------------------------
#endif
