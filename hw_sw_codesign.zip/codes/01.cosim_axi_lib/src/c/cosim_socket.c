/*
 * Copyright (c) 2022 by Future Design Systems.
 * All right reserved.
 * http://www.future-ds.com
 *
 * @file cosim_socket.h
 * @brief This file contains functions for XDMA lowlevel.
 * @author Ando Ki
 * @date 2022.11.05.
 */
// several ways to deal with socket port in use.
// $ lsof -i :<port>
// $ lsof -t -i :<port> | xargs -r kill -9
// $ fuser 230/tcp
// $ fuser -k 230/tcp
// $ sudo ss --kill state listening src :2300
// $ iptable -I INPUT -p tcp --dport 2300 -j DROP
// $ npx kill-port 2300
//
#include <sys/socket.h>
#include <arpa/inet.h> //inet_addr
#include <unistd.h>    //write
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <strings.h>

#include "cosim_socket.h"

#if defined(DEBUG)||defined(RIGOR)
#define PRINTF(format, ...)\
    do { if (m_verbose>0) {\
             printf("%s(): " format, __func__, ##__VA_ARGS__);\
             fflush(stdout); }} while (0)
#else
#define PRINTF(...) do { } while (0)
#endif

static int m_verbose=0;

int socket_release( CosimSocketHandle_t handle )
{
    if (handle!=NULL) {
        if (handle->sock) close(handle->sock);
        free(handle);
    }
    return 0;
}

// Create socket on the 'port', try to bind, and return socket for server.
//
// port:
// nonblock: non-blocking mode when 1
//
// return socket on success.
// return NULL on failure.
CosimSocketHandle_t socket_init_server( int port, int nonblock )
{
    CosimSocketHandle_t handle=NULL;

    int sock_fd=0;
    
    if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        PRINTF("ERROR: Socket creation failed\n");
        return NULL;
    }
    PRINTF("Socket created\n");

    int enable=1;
    setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, (char *)&enable, (int)sizeof(enable));
    
    struct sockaddr_in server;
    bzero((char *) &server, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(port);
    if (bind(sock_fd, (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        PRINTF("ERROR: Bind failed\n");
        return NULL;
    }
    PRINTF("Bind done\n");

    listen(sock_fd , 3);

    int sock=0;
    struct sockaddr_in client;
    int clilen = sizeof(client);
    do {
        sock = accept(sock_fd, (struct sockaddr *)&client, &clilen);
        if (sock < 0)
        {
            PRINTF("Error: accept() failed\n");
            return NULL; // continue
        }
    } while (sock<=0);
    PRINTF("Accepted connection from %s\n", inet_ntoa(client.sin_addr));

    if (nonblock==COSIM_SOCKET_MODE_NONBLOCK) {
        int flag = fcntl(sock, F_GETFL, 0);
        fcntl(sock, F_SETFL, flag | O_NONBLOCK);
    }

    handle = (CosimSocketHandle_t)calloc(1, sizeof(struct CosimSocketHandle));
    if (handle==NULL) {
        PRINTF("handler alloc failed for port %u\n", port);
        return NULL;
    }
    handle->type = COSIM_SOCKET_TYPE_SERVER;
    handle->port = port;
    handle->sock = sock;
    handle->mode = (nonblock==COSIM_SOCKET_MODE_NONBLOCK) ? COSIM_SOCKET_MODE_NONBLOCK
                                                          : COSIM_SOCKET_MODE_BLOCK;
    
    return handle;
}

// Create socket on the 'port', try to bind, and return socket for client.
//
// server_port:
// server_ip: '127.0.0.1' / 'localhost'
// nonblock: non-blocking mode when 1
//
// return socket on success.
// return negative number on failure.
CosimSocketHandle_t socket_init_client( int   server_port
                                      , char *server_ip
                                      , int   nonblock )
{
    CosimSocketHandle_t handle=NULL;

    int sock_fd = 0;
    if ((sock_fd=socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        PRINTF("ERROR: Socket creation failed\n");
        return NULL;
    }

    // create server address
    struct sockaddr_in serv_addr;
    memset(&serv_addr, '0', sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(server_port);
    // convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, server_ip, &serv_addr.sin_addr) <= 0)
    {
        PRINTF("ERROR: server IP address failed.\n");
        return NULL;
    }
    if (connect(sock_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        PRINTF("ERROR: Unable to connect to server\n");
        return NULL;
    }
    PRINTF("Connected to %s\n", server_ip);

    if (nonblock==COSIM_SOCKET_MODE_NONBLOCK) {
        int flag = fcntl(sock_fd, F_GETFL, 0);
        fcntl(sock_fd, F_SETFL, flag | O_NONBLOCK);
    }

    handle= (CosimSocketHandle_t)calloc(1, sizeof(struct CosimSocketHandle));
    if (handle==NULL) {
        PRINTF("handler alloc failed for port %u\n", server_port);
        return NULL;
    }
    handle->type = COSIM_SOCKET_TYPE_CLIENT;
    handle->port = server_port;
    handle->sock = sock_fd;
    handle->mode = (nonblock==COSIM_SOCKET_MODE_NONBLOCK) ? COSIM_SOCKET_MODE_NONBLOCK
                                                          : COSIM_SOCKET_MODE_BLOCK;
    
    return handle;
}

// receiving data throuh socket.
int socket_read( CosimSocketHandle_t handle, char *buff, int size )
{
    int nread;

    nread = read(handle->sock, buff, size);

    return nread;
}

// sendind data throuh socket.
int socket_write( CosimSocketHandle_t handle, char *buff, int size )
{
    int nwrite;
    nwrite = write(handle->sock, buff, size);

    return nwrite;
}

int socket_get_socket_buffer(int sock)
{
    int size;
    int rn=sizeof(size);
    getsockopt(sock, SOL_SOCKET, SO_SNDBUF, &size, &rn);

    return size;
}

int socket_set_socket_buffer(int sock, int size)
{
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &size, sizeof(size));

    return socket_get_socket_buffer(sock);
}
#undef PRINTF

// Call type | Socket state | blocking | Nonblocking
//----
// Types of read() calls | Input is available    | Immediate return  | Immediate return
//                       | No input is available | Wait for input    | Immediate return with EWOULDBLOCK error number (select() exception: READ)
//----
//Types of write() calls | Output buffers available     | Immediate return        | Immediate return
//                       | No output buffers available  | Wait for output buffers | Immediate return with EWOULDBLOCK error number (select() exception: WRITE)
//----
//accept() call          | New connection          | Immediate return        |  Immediate return
//                       | No connections queued   | Wait for new connection |  Immediate return with EWOULDBLOCK error number (select() exception: READ)
//connect() call         |                         | Wait                    |  Immediate return with EINPROGRESS error number (select() exception: WRITE)
//----
/* Revision history
 *
 * 2022.11.05: Updated.
 * 2022.10.15: Started by Ando Ki (adki@future-ds.com)
 */
