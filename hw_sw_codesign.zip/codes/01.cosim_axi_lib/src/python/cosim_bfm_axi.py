#!/usr/bin/env python3
"""
This file contains common part of Python interface of of Co-Simulation BFM.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

#-------------------------------------------------------------------------------
__author__     = "Ando Ki"
__copyright__  = "Copyright 2022, Ando Ki"
__credits__    = ["none", "some"]
__license__    = "FUTURE DESIGN SYSTEMS SOFTWARE END-USER LICENSE AGREEMENT"
__version__    = "0"
__revision__   = "0"
__maintainer__ = "Ando Ki"
__email__      = "andoki@gmail.com"
__status__     = "Development"
__date__       = "2024.11.28"
__description__= "Python interface of Co-Simulation BFM AXI-Lite"

#-------------------------------------------------------------------------------
import sys
import typing
import ctypes
import cosim_api as cosim

#------------------------------------------------------------------------------
# [AXI-lite Memory Map Access]
#     +---+---+---+---+
#     | flag  | cmd   |
#     +---+---+---+---+
#     | addr          |
#     +---+---+---+---+
#     | data          |
#     +---+---+---+---+
#----------------------------------------------------------------------------
# [AXI-stream Access]
#     +---+---+---+---+ --
#     | flag  | cmd   |  | flag[0]=start, falg[1]=last
#     +---+---+---+---+  |
#     | sizeU | sizeD |  | (COSIM_CMD_SIZE=8)
#     +---+---+---+---+ --     --
#     |   |   |   |   | data    |
#     +---+---+---+---+         | size_data
#     |   |   |   |   | data    |
#     +---+---+---+---+         |
#     |   |   |   |   | data    |
#     +---+---+---+---+        --
#     |   |   |   |   | user    |
#     +---+---+---+---+         | size_user
#     |   |   |   |   | user    |
#     +---+---+---+---+        --
#------------------------------------------------------------------------------

class CosimBfmAxi:
    #------------------------------------------------------------------------------
    # 'cmd' field for AXI-lite memory map
    COSIM_CMD_NULL       =0x0000
    COSIM_CMD_RD_REQ     =0x0001
    COSIM_CMD_WR_REQ     =0x0002
    COSIM_CMD_RD_RSP_ACK =0x1001
    COSIM_CMD_RD_RSP_NACK=0x2001
    COSIM_CMD_WR_RSP_ACK =0x1002
    COSIM_CMD_WR_RSP_NACK=0x2002

    # 'cmd' field for AXI-mm memory map
    COSIM_CMD_RD_MM_REQ         =0x0004
    COSIM_CMD_WR_MM_REQ         =0x0005
    COSIM_CMD_RD_MM_RSP_ACK     =0x1004
    COSIM_CMD_RD_MM_RSP_NACK    =0x2004
    COSIM_CMD_WR_MM_RSP_ACK     =0x1005
    COSIM_CMD_WR_MM_RSP_NACK    =0x2005
    COSIM_CMD_CONFIG_MM_REQ        =0x0006
    COSIM_CMD_CONFIG_MM_RSP_ACK    =0x1006
    COSIM_CMD_CONFIG_MM_RSP_NACK   =0x2006
    
    # 'cmd' field for AXI-stream memory map
    COSIM_CMD_H2C_REQ        =0x000A
    COSIM_CMD_C2H_REQ        =0x000B
    COSIM_CMD_H2C_RSP_ACK    =0x100A
    COSIM_CMD_H2C_RSP_NACK   =0x200A
    COSIM_CMD_C2H_RSP_ACK    =0x100B
    COSIM_CMD_C2H_RSP_NACK   =0x200B
    COSIM_CMD_CONFIG_REQ     =0x000C
    COSIM_CMD_CONFIG_RSP_ACK =0x100C
    COSIM_CMD_CONFIG_RSP_NACK=0x200C
    
    # 'cmd' field for simulation control
    COSIM_CMD_TERM_REQ     =0x0010
    COSIM_CMD_TERM_RSP_ACK =0x1010
    COSIM_CMD_TERM_RSP_NACK=0x2010
    
    #------------------------------------------------------------------------------
    # for 'cmd_ack' field
    COSIM_CMD_ACK_ERR=0x0
    COSIM_CMD_ACK_OK =0x1

    #------------------------------------------------------------------------------
    # for cmd_rd/wr_mm
    COSIM_CMD_MM_BURST_FIXED =0
    COSIM_CMD_MM_BURST_INC   =1
    COSIM_CMD_MM_BURST_WRAP  =2
    
    #------------------------------------------------------------------------------
    # maximum number of channels, i.e., sockets
    COSIM_MAX_NUM_CHAN=8
    
    #------------------------------------------------------------------------------
    # command channels to control termination
    COSIM_CHAN_ID=0
    
    #------------------------------------------------------------------------------
    # command channels to control termination
    COSIM_PORT=0x00002300
    
    #------------------------------------------------------------------------------
    # for 'data[]' field
    COSIM_DATA_BNUM=(4*1024) #considering stream
    
    #------------------------------------------------------------------------------
    # for 'data[]' field
    COSIM_CMD_SIZE=8
    
    #------------------------------------------------------------------------------
    _cid     = 0
    _port    = 0x2300
    _rigor   = 0
    _verbose = 0
    _cosim:cosim.CoSim = None

    #-------------------------------------------------------------------------------
    def __init__ ( self
                 , cid:int=0
                 , port:int=0x2300
                 , rigor:int=0
                 , verbose:int=0) -> None:
        self._cid     = cid
        self._port    = port
        self._rigor   = rigor
        self._verbose = verbose
        self._cosim   = cosim.CoSim(cid,port,'server',rigor,verbose)
                        # this calls loading library and open communication channel
        if self._cosim==None:
            sys.exit(1)

    def __del__ ( self ):
        self.bfm_axi_finish()
        if self._cosim is not None: del self._cosim
                                    # this calls closing communication channel

    def __str__ ( self ):
        print(f"cid    :{self._cid}")
        print(f"port   :{self._port}")
        print(f"rigor  :{self._rigor}")
        print(f"verbose:{self._verbose}")

    #---------------------------------------------------------------------------
    #  [REQ]                  [RESP]
    #  +---+---+---+---+      +---+---+---+---+ 
    #  | flag  | cmd   |      | flag  | cmd   | 
    #  +---+---+---+---+      +---+---+---+---+ 
    #  | addr          |      | addr          | 
    #  +---+---+---+---+      +---+---+---+---+ 
    #  | data          |      |data(dont'care)| 
    #  +---+---+---+---+      +---+---+---+---+ 

    def axi_lite_write( self, addr:ctypes.c_uint32=0, data:ctypes.c_uint32=0 ) -> bool:
        """BFM WRITE
        """
        cmd = self.COSIM_CMD_WR_REQ
        flag = 0
        bytes_cmd  = cmd.to_bytes(2, 'little')
        bytes_flag = flag.to_bytes(2, 'little')
        bytes_addr = addr.to_bytes(4, 'little')
        bytes_data = data.to_bytes(4, 'little')
        buff_tx = bytes_cmd+bytes_flag+bytes_addr+bytes_data
        bnum = len(buff_tx)
        buff_rx = bytearray([0x00] * bnum)

        self._cosim.snd(buff_tx, bnum )
        self._cosim.rcv(buff_rx, bnum )
    
       #print(f"int.from_bytes(buff_rx[0:2],'little')={hex(int.from_bytes(buff_rx[0:2],'little'))}")
        if int.from_bytes(buff_rx[0:2],'little')==self.COSIM_CMD_WR_RSP_ACK:
            return True
        else:
            return False
    
    #---------------------------------------------------------------------------
    #  [REQ]                  [RESP]
    #  +---+---+---+---+      +---+---+---+---+ 
    #  | flag  | cmd   |      | flag  | cmd   | 
    #  +---+---+---+---+      +---+---+---+---+ 
    #  | addr          |      | addr          | 
    #  +---+---+---+---+      +---+---+---+---+ 
    #  |data(dont'care)|      | data          | 
    #  +---+---+---+---+      +---+---+---+---+ 

    def axi_lite_read( self, addr:ctypes.c_uint32=0 ) -> typing.Union[int, None]:
        """BFM READ
        """
        cmd = self.COSIM_CMD_RD_REQ
        flag = 0
        bytes_cmd  = cmd.to_bytes(2, 'little')
        bytes_flag = flag.to_bytes(2, 'little')
        bytes_addr = addr.to_bytes(4, 'little')
        bytes_data = bytearray([0x00] * 4)
        buff_tx = bytes_cmd+bytes_flag+bytes_addr+bytes_data
        bnum = len(buff_tx)
        buff_rx = bytearray([0x00] * bnum)
        
        self._cosim.snd(buff_tx, bnum )
        self._cosim.rcv(buff_rx, bnum )
    
        if int.from_bytes(buff_rx[0:2],'little')==self.COSIM_CMD_RD_RSP_ACK:
            return int.from_bytes(buff_rx[8:12], 'little', signed=False)
        else:
            return None

    #---------------------------------------------------------------------------
    #  [REQ]                 [RESP]
    #  +---+---+---+---+     +---+---+---+---+
    #  | flag  | cmd   |     | flag  | cmd   |
    #  +---+---+---+---+     +---+---+---+---+
    #  | addr[31:0]    |     | addr[31:0]    |
    #  +---+---+---+---+     +-------+-------+
    #  | addr[63:32]   |     | addr[63:32]   |
    #  +---+---+---+---+     +-------+-------+
    #  |     L | S | M |     |     L | S | M |
    #  +---+---+---+---+     +---+---+---+---+
    #  |   |   |   |   | data byte stream
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+

    def axi_write( self
                 , addr:ctypes.c_uint64=0
                 , data:bytes=0
                 , size:ctypes.c_uint32=4
                 , leng:ctypes.c_uint32=1 ) -> bool:
        """BFM WRITE
        :param: addr
        :param: data
        :param: size   num of bytes for a beat
        :param: leng   num of beat, i.e., burst length
        """
        if len(data)!=size*leng:
            print(f"axi_write() size of data not matcch.")
            return False
        cmd = self.COSIM_CMD_WR_MM_REQ
        flag = 0
        dummy = 0
        burst = self.COSIM_CMD_MM_BURST_INC
        bytes_cmd  = cmd.to_bytes(2, 'little')
        bytes_flag = flag.to_bytes(2, 'little')
        bytes_addr = addr.to_bytes(8, 'little')
       #bytes_data = dummy.to_bytes(4, 'little')
        bytes_burst = burst.to_bytes(1, 'little')
        bytes_size = size.to_bytes(1, 'little')
        bytes_leng = leng.to_bytes(2, 'little')
        buff_tx = bytes_cmd+bytes_flag+bytes_addr+bytes_burst+bytes_size+bytes_leng+data
       #buff_tx = bytes_cmd+bytes_flag+bytes_addr+bytes_data+bytes_burst+bytes_size+bytes_leng+data
        bnum_tx = len(buff_tx)
        bnum_rx = bnum_tx-len(data)
        buff_rx = bytearray([0x00] * bnum_rx)

        self._cosim.snd(buff_tx, bnum_tx )
        self._cosim.rcv(buff_rx, bnum_rx )
    
        if int.from_bytes(buff_rx[0:2],'little')==self.COSIM_CMD_WR_MM_RSP_ACK:
            return True
        else:
            return False
    
    #---------------------------------------------------------------------------
    #  [REQ]                 [RESP]
    #  +---+---+---+---+     +---+---+---+---+
    #  | flag  | cmd   |     | flag  | cmd   |
    #  +---+---+---+---+     +---+---+---+---+
    #  | addr[31:0]    |     | addr[31:0]    |
    #  +---+---+---+---+     +-------+-------+
    #  | addr[63:32]   |     | addr[63:32]   |
    #  +---+---+---+---+     +-------+-------+
    #  |     L | S | M |     |     L | S | M |
    #  +---+---+---+---+     +---+---+---+---+
    #                        |   |   |   |   | data byte stream
    #                        +---+---+---+---+
    #                        |   |   |   |   |
    #                        +---+---+---+---+
    #                        |   |   |   |   |
    #                        +---+---+---+---+
    #                        |   |   |   |   |
    #                        +---+---+---+---+

    def axi_read( self
                , addr:ctypes.c_uint64=0
                , data:bytes=0
                , size:ctypes.c_uint32=4
                , leng:ctypes.c_uint32=1 ) -> bool: # typing.Union[int, None]:
        """BFM READ
        :param: addr
        :param: data
        :param: size   num of bytes for a beat
        :param: leng   num of beat, i.e., burst length
        """
        if len(data)!=size*leng:
            print(f"axi_write() size of data not matcch.")
            return False
        cmd = self.COSIM_CMD_RD_MM_REQ
        flag = 0
        dummy = 0
        burst = self.COSIM_CMD_MM_BURST_INC
        bytes_cmd  = cmd.to_bytes(2, 'little')
        bytes_flag = flag.to_bytes(2, 'little')
        bytes_addr = addr.to_bytes(8, 'little')
       #bytes_data = dummy.to_bytes(4, 'little')
        bytes_burst = burst.to_bytes(1, 'little')
        bytes_size = size.to_bytes(1, 'little')
        bytes_leng = leng.to_bytes(2, 'little')
        buff_tx = bytes_cmd+bytes_flag+bytes_addr+bytes_burst+bytes_size+bytes_leng
       #buff_tx = bytes_cmd+bytes_flag+bytes_addr+bytes_data+bytes_burst+bytes_size+bytes_leng
        bnum_tx = len(buff_tx)
        bnum_rx = bnum_tx + size*leng
        buff_rx = bytearray([0x00] * bnum_rx)
        
        self._cosim.snd(buff_tx, bnum_tx )
        self._cosim.rcv(buff_rx, bnum_rx )
    
        if int.from_bytes(buff_rx[:2],'little')==self.COSIM_CMD_RD_MM_RSP_ACK:
            for idx in range(size*leng): data[idx] = buff_rx[bnum_tx+idx]
            return True
        else:
            return None

    #-------------------------------------------------------------------------------
    # it returns width of data and addr
    def axi_mm_get_config ( self ) -> typing.Tuple[int, int, int]:
        """BFM get config
        Returns:
           width_data and width_user (in bytes)
           mode of BFM: 3'b001:axi-lite 3'b010:axi-stream, 3'b100:axi-mm, 3'b111: all
        """
        cmd = self.COSIM_CMD_CONFIG_MM_REQ
        bytes_cmd   = cmd.to_bytes(4, 'little') # note 4 not 2
        bytes_dummy = bytearray([0x00] * 4)
        buff_tx = bytes_cmd+bytes_dummy
        bnum = len(buff_tx)
        buff_rx = bytearray([0x00] * bnum)
        
        num_sent  = self._cosim.snd(buff_tx, bnum )
        num_rcved = self._cosim.rcv(buff_rx, bnum )
    
        if int.from_bytes(buff_rx[0:2], 'little')==self.COSIM_CMD_CONFIG_MM_RSP_ACK:
            # width_data  width_user mode
            return int.from_bytes(buff_rx[4:6], 'little'),\
                   int.from_bytes(buff_rx[6:8], 'little'),\
                   int.from_bytes(buff_rx[2:4], 'little')
        else:
            return 0, 0, 0

    #-------------------------------------------------------------------------------
    #  [REQ]                  [RESP]
    #  +---+---+---+---+      +---+---+---+---+
    #  | flag  | cmd   |      | flag  | cmd   |
    #  +---+---+---+---+      +---+---+---+---+
    #  | sizeU | sizeD |      | sizeU | sizeD |
    #  +---+---+---+---+      +-------+-------+
    #  |   |   |   |   |
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+
    #  |   |   |   |   |
    #  +---+---+---+---+

    def axi_stream_h2c( self
                      , data:bytes
                      , size_data:int
                      , user:bytes
                      , size_user:int
                      , last:int ) -> bool:
        """BFM Host-to-Card, i.e, TX
        """
        if len(data)!=size_data:
           print(f"data size mis-match.")
           return False
        if len(user)!=size_user:
           print(f"user data size mis-match.")
           return False
        cmd             = self.COSIM_CMD_H2C_REQ;
        flag            = (last&0x1)<<1;
        bytes_cmd       = cmd.to_bytes(2, 'little')
        bytes_flag      = flag.to_bytes(2, 'little')
        bytes_size_user = size_user.to_bytes(2, 'little')
        bytes_size_data = size_data.to_bytes(2, 'little')
        buff_tx         = bytes_cmd+bytes_flag+bytes_size_data+bytes_size_user\
                        + data + user
        bnum = len(buff_tx)
        buff_rx = bytearray([0x00] * 64) # more than 8 bytes
        
        self._cosim.snd(buff_tx, bnum )
        self._cosim.rcv(buff_rx, 64 )
    
        if int.from_bytes(buff_rx[0:2], 'little')==self.COSIM_CMD_H2C_RSP_ACK:
            return True
        else:
            return False
    
    #-------------------------------------------------------------------------------
    #  [REQ]                  [RESP]
    #  +---+---+---+---+      +---+---+---+---+
    #  | flag  | cmd   |      | flag  | cmd   |
    #  +---+---+---+---+      +---+---+---+---+
    #  | sizeU | sizeD |      | sizeU | sizeD |
    #  +---+---+---+---+      +-------+-------+
    #                         |   |   |   |   |
    #                         +---+---+---+---+
    #                         |   |   |   |   |
    #                         +---+---+---+---+
    #                         |   |   |   |   |
    #                         +---+---+---+---+
    #                         |   |   |   |   |
    #                         +---+---+---+---+
    #                         |   |   |   |   |
    #                         +---+---+---+---+

    def axi_stream_c2h( self
                      , size_data:int
                      , size_user:int ) -> typing.Tuple[typing.Union[bytearray,None], typing.Union[bytearray,None], typing.Union[int,None]]:
        """BFM Card-to-Host, i.e., RX
        Aguments:
            size_data: it give a hint to get data
            size_user: it give a hint to get user
        """
        cmd             = self.COSIM_CMD_C2H_REQ;
        flag            = 0
        bytes_cmd       = cmd.to_bytes(2, 'little')
        bytes_flag      = flag.to_bytes(2, 'little')
        bytes_size_user = size_user.to_bytes(2, 'little')
        bytes_size_data = size_data.to_bytes(2, 'little')
    
        buff_tx = bytes_cmd+bytes_flag+bytes_size_data+bytes_size_user
        bnum_tx = len(buff_tx)
        bnum_rx = bnum_tx+size_data+size_user
        buff_rx = bytearray([0x00] * bnum_rx) # make sure sufficient rooms
        
        num_snt = self._cosim.snd(buff_tx, bnum_tx )
        num_rcv = self._cosim.rcv(buff_rx, bnum_rx )
    
        if num_rcv<self.COSIM_CMD_SIZE:
            print(f"Too small number of bytes receive: {num_rcv}")
            return None, None, None
    
        if int.from_bytes(buff_rx[0:2], 'little')==self.COSIM_CMD_C2H_RSP_ACK:
              last = (buff_rx[2]&0x2)
              size_data_rcv = int.from_bytes(buff_rx[4:6], 'little')
              size_user_rcv = int.from_bytes(buff_rx[6:8], 'little')
              data =  buff_rx[self.COSIM_CMD_SIZE:self.COSIM_CMD_SIZE+size_data_rcv]
              if size_user_rcv==0: user = None
              else: user =  buff_rx[self.COSIM_CMD_SIZE+size_data_rcv:self.COSIM_CMD_SIZE+size_data_rcv+size_user_rcv]
             #print(f"size_data_rcv={size_data_rcv} size_user_rcv={size_user_rcv} len(data)={len(data)} len(user)={len(user)}")
             #print(f"buff_rx={buff_rx}")
             #print(f"data={data}")
             #print(f"user={user}")
              return data, user, last
        else:
            return None, None, None
    
    #-------------------------------------------------------------------------------
    # it returns width of data and user
    def axi_stream_get_config ( self ) -> typing.Tuple[int, int, int]:
        """BFM get config
        Returns:
           width_data and width_user (in bytes)
           mode of BFM: 3'b001:axi-lite 3'b010:axi-stream, 3'b100:axi-mm, 3'b111: all
        """
        cmd = self.COSIM_CMD_CONFIG_REQ
        bytes_cmd   = cmd.to_bytes(4, 'little') # note 4 not 2
        bytes_dummy = bytearray([0x00] * 4)
        buff_tx = bytes_cmd+bytes_dummy
        bnum = len(buff_tx)
        buff_rx = bytearray([0x00] * bnum)
        
        num_sent  = self._cosim.snd(buff_tx, bnum )
        num_rcved = self._cosim.rcv(buff_rx, bnum )
    
        if int.from_bytes(buff_rx[0:2], 'little')==self.COSIM_CMD_CONFIG_RSP_ACK:
            # width_data  width_user mode
            return int.from_bytes(buff_rx[4:6], 'little'),\
                   int.from_bytes(buff_rx[6:8], 'little'),\
                   int.from_bytes(buff_rx[2:4], 'little')
        else:
            return 0, 0, 0
    
    #-------------------------------------------------------------------------------
    def bfm_axi_finish( self ) -> bool:
        """BFM finish
        """
        cmd = self.COSIM_CMD_TERM_REQ
        bytes_cmd   = cmd.to_bytes(4, 'little') # note 4 not 2
        bytes_dummy = bytearray([0x00] * 8) # addr, data
        buff_tx = bytes_cmd+bytes_dummy
        bnum = len(buff_tx)
        buff_rx = bytearray([0x00] * bnum)
        
        if self._cosim is not None:
            self._cosim.snd(buff_tx, bnum)
            self._cosim.rcv(buff_rx, bnum)
    
        if int.from_bytes(buff_rx[0:2], 'little')==self.COSIM_CMD_TERM_RSP_ACK:
            return True
        else:
            return False

#===============================================================================
if __name__=='__main__':
    import getopt
    import multiprocessing

    cid = 0;
    port = 0x2300;
    verbos = 0
    rigor = 0
    mode  = 'mm'

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hg:r:C:P:", ['help'
                                                            ,  'axi='
                                                            ,  'verbose='
                                                            ,  'rigor='
                                                            ,  'cid='
                                                            ,  'port='])
    except getopt.GetoptError:
        sys.exit(2)
    else:
        for opt, arg in opts:
            if opt in ("-h", "--help"):
                print(f"{sys.argv[0]} [options]")
                print(f" -h/--help: help")
                print(f' -a/--axi="lite|mm|stream": set mode')
                print(f" -g/--verbose=num: set verbose level")
                print(f" -C/--cid=num: set channel id")
                print(f" -P/--port=num: set socket port")
                sys.exit()
            elif opt in ("-C","--cid"):
                cid = int(arg, 0)
            elif opt in ("-P","--port"):
                port = int(arg, 0)
            elif opt in ("-a","--axi"):
                mode = arg
            elif opt in ("-g","--verbose"):
                verbose = int(arg)
            elif opt in ("-r","--rigor"):
                rigor = int(arg)
            else:
                print("Unknown options: "+str(opt))
                sys.exit(1)

    hdl = CosimBfmAxi(cid,port,rigor,verbose)

    if mode=="lite":
        addr:ctypes.c_uint32  = 0x00000140
        dataW:ctypes.c_uint32 = 0x12345678
        hdl.axi_lite_write(addr, dataW)
        dataR = hdl.axi_lite_read(addr)
        if dataR is not None and dataR==dataW:
            print(f"OK {hex(dataR)}")
        else:
            print(f"Mis-match: {hex(dataR)}/{hex(dataW)}")

    elif mode=="mm":
        addr:ctypes.c_uint64  = 0x00000140
        dataW = 0x12345678
        bytes_dataW  = dataW.to_bytes(4, 'little')
        bytes_dataR  = [0x00]*4
        if hdl.axi_write(addr, bytes_dataW, 4, 1)==False:
            print(f"axi_write error")
        if hdl.axi_read(addr, bytes_dataR, 4, 1)==False:
            print(f"axi_read error")
        dataR = int.from_bytes(bytes_dataR, 'little')
        if dataR==dataW:
            print(f"OK {hex(dataR)}")
        else:
            print(f"Mis-match: {hex(dataR)}/{hex(dataW)}")

        dwidth, awidth, conf = hdl.axi_mm_get_config()
        print(f"dwidth={dwidth} awidth={awidth}, conf={conf}")

        size = dwidth//8
        leng = 8
        bytes_dataW = bytearray(size*leng)
        bytes_dataR = bytearray(size*leng)
        for i in range(size*leng):
            bytes_dataW[i] = (i+1)&0xFF
        if hdl.axi_write(addr, bytes_dataW, size, leng)==False:
            print(f"axi_write error")
        if hdl.axi_read(addr, bytes_dataR, size, leng)==False:
            print(f"axi_read error")
        error = 0;
        for j in range(size*leng):
            if bytes_dataW[j]!=bytes_dataR[j]: error = error + 1
        if error == 0: print(f"axi mm test for {size}-byte {leng}-length OK.")
        else:          print(f"axi mm test for {size}-byte {leng}-length Mis-match {error}-bytes out of {size*leng}-bytes.")

    elif mode=="stream":
        width_data, width_user, mode = hdl.axi_stream_get_config ()
        Tsize_data_item   = (width_data+7)//8 # num of bytes per data item
        Tsize_user_item   = (width_user+7)//8 # num of bytes per user item

        Titems = 5 # number of items to push
        Tsize_data_stream = Titems*Tsize_data_item # number of bytes for all
        Tsize_user_stream = Titems*Tsize_user_item # number of bytes for all
        bytes_dataW = bytearray(Tsize_data_stream)
        bytes_userW = bytearray(Tsize_user_stream)

        mask = (1<<width_user)-1;
        bytes_mask = bytearray(Tsize_user_item)
       #print(f"width_user={width_user} mask={mask}")
        for idx in range(Tsize_user_item): # mask for one item
            bytes_mask[idx] = mask&0xFF;
            mask = mask>>8;
       #print(f"bytes_mask={bytes_mask}")

        idw = 0;
        idz = 0;
        for idx in range(Titems):
            for idy in range(Tsize_data_item):
                bytes_dataW[idz] = (idx*Tsize_data_item + idy)&0xFF
                idz = idz + 1

            for idy in range(Tsize_user_item):
                bytes_userW[idw] = (idx*Tsize_user_item + idy)&bytes_mask[idy]
                idw = idw + 1

       #print(f"bytes_dataW={bytes_dataW}")
       #print(f"bytes_userW={bytes_userW}")

        Tlast = 1;
        hdl.axi_stream_h2c(bytes_dataW, Tsize_data_stream, bytes_userW, Tsize_user_stream, Tlast)
        Rdata, Ruser, Rlast = hdl.axi_stream_c2h(Tsize_data_stream, Tsize_user_stream)

       #print(f"Rdata={Rdata}")
       #print(f"Ruser={Ruser}")

        if len(Rdata)!=Tsize_data_stream: print(f"data size mis-match len(Rdata)={len(Rdata)} {Tsize_data_stream}")
        if len(Ruser)!=Tsize_user_stream: print(f"user data size mis-match len(Ruser)={len(Ruser)} {Tsize_user_stream}")

        error = 0;
        idw = 0;
        idz = 0;
        for idx in range(Titems):
            for idy in range(Tsize_data_item):
                if bytes_dataW[idz]!=Rdata[idz]:
                   print(f"Mis-match data [{idz}] {hex(Rdata[idz])}, but {hex(bytes_dataW[idz])} expected")
                   error = error + 1
            idz = idz + 1
        if error==0: print(f"Data OK {Tsize_data_stream}-byte")
        else:        print(f"Data mis-match {error} out of {Tsize_data_stream}-byte")

        error = 0;
        for idx in range(Titems):
            for idy in range(Tsize_user_item):
                if bytes_userW[idw]!=Ruser[idw]:
                   print(f"Mis-match user data [{idw}] {hex(Ruser[idw])}, but {hex(bytes_userW[idw])} expected")
                   error = error + 1
            idw = idw + 1
        if error==0: print(f"User data OK {Tsize_user_stream}-byte")
        else:        print(f"User data mis-match {error} out of {Tsize_user_stream}-byte")
    else:
        print(f'Unkown option: "{mode}"')

    del hdl

#===============================================================================
# Revision history:
#
# 2024.11.28: 'bfm_axi_finish()' bug-fixed.
#            if self._cosim is not None:
#                self._cosim.snd(buff_tx, bnum)
#                self._cosim.rcv(buff_rx, bnum)
# 2024.07.24: 'axi_read()' hint changed.
# 2022.11.18: Started        by Ando Ki     (andoki@gmail.com)
#===============================================================================
