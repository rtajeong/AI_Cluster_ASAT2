#!/usr/bin/env python3
"""
This file contains common part of Python interface of of Co-Simulation BFM.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

#-------------------------------------------------------------------------------
__author__     = "Ando Ki"
__copyright__  = "Copyright 2022, Ando Ki"
__credits__    = ["none", "some"]
__license__    = "FUTURE DESIGN SYSTEMS SOFTWARE END-USER LICENSE AGREEMENT"
__version__    = "0"
__revision__   = "0"
__maintainer__ = "Ando Ki"
__email__      = "andoki@gmail.com"
__status__     = "Development"
__date__       = "2022.11.18"
__description__= "Python interface of Co-Simulation BFM"

#-------------------------------------------------------------------------------
import os
import sys
import platform
import traceback
import inspect
import ctypes
import ctypes.util

#===============================================================================
# utility functions
# print GetFunctionName()+'('+str(GetFunctionParametersAndValues())+')'
def GetLineno():
    """
    Returns the current line number in the program.
    :return: integer of the line number.
    """
    return inspect.currentframe().f_back.f_lineno

def GetFunctionName():
    """
    Returns the current function name in the program.
    :return: string of the function name.
    """
    return traceback.extract_stack(None, 2)[0][2]

def GetFunctionParametersAndValues():
    """
    Returns the dictionary of function arguments in the program.
    :return: disctionary of function arguments.
    """
    frame = inspect.currentframe().f_back
    args, _, _, values = inspect.getargvalues(frame)
    return ([(i, values[i]) for i in args])

def CosimError(*args, **kwargs):
    print(traceback.extract_stack(None, 2)[0][2], "Error: ".join(map(str,args)), **kwargs)

def CosimWarn(*args, **kwargs):
    print(traceback.extract_stack(None, 2)[0][2], "Warning: ".join(map(str,args)), **kwargs)

def CosimInfo(*args, **kwargs):
    print(traceback.extract_stack(None, 2)[0][2], "Info: ".join(map(str,args)), **kwargs)

def CosimPrint(*args, **kwargs):
    print(traceback.extract_stack(None, 2)[0][2], " ".join(map(str,args)), **kwargs)

#-------------------------------------------------------------------------------
# utility functions: function signature or function wrapper
def WrapFunction(lib, funcname, restype, argtypes):
    """
    Simplify wrapping ctypes functions
    :param lib: library (object returned from ctypes.CDLL()
    :param funcname: string of function name
    :param restype: type of return value
    :param argtypes: a list of types of the function arguments
    :return: Python object holding function, restype and argtypes.
    """
    func = lib.__getattr__(funcname)
    func.restype = restype
    func.argtypes = argtypes
    return func

#===============================================================================
class CoSim:
    """This is CoSim class."""
    _libcosim = None #path to libcosim_api.so
    _cosim    = None
    _cid      = 0
    _port     = 0x2300
    _rigor    = 0
    _verbose  = 0

    #-------------------------------------------------------------------------------
    def __init__( self
                , cid:int= 0
                , port:int=0x2300
                , mode:str='server'
                , rigor=0
                , verbose=0):
        """Initialize CoSim class
        :param cid: integer, IPC channel ID
        :param port: integer, Socket port
        :param mode: string, 'server' or 'client'
        :return: 0 on success, otherwise return negative number
        """
        self._rigor   = rigor
        self._verbose = verbose
        self._cid     = cid
        self._port    = port
        self._mode    = mode
        # let check 'COSIM_HOME' environment variable
        if 'COSIM_HOME' not in os.environ:
           print (GetFunctionName(), "Warning: the environment variable COSIM_HOME not defined.", flush=True)
           self.COSIM_HOME='..'
        else:
           self.COSIM_HOME=os.environ["COSIM_HOME"]
        self.LoadCosimLib()

        self.set_verbose( verbose )

        if self.open( )<0:
            traceback.print_exc(file=sys.stdout)
            sys.exit(1)

    #-------------------------------------------------------------------------------
    def __del__( self ):
        self.close( )

    #-------------------------------------------------------------------------------
    def __str__( self ):
        print(f"_libcosim   : {self._libcosim   }")
        print(f"_cosim      : {self._cosim      }")
        print(f"_cid        : {self._cid        }")
        print(f"_port: {self._port}")
        print(f"_rigor      : {self._rigor      }")
        print(f"_verbose    : {self._verbose    }")

    #-------------------------------------------------------------------------------
    def LoadCosimLib( self ):
        """
        Load C shared library.
        """
        self._libcosim = os.path.abspath( os.path.join(self.COSIM_HOME, "lib", "libcosim.so"))
        if not os.path.isfile(self._libcosim):
           print (GetFunctionName(), self._libcosim+' is not a file', flush=True)
           traceback.print_exc(file=sys.stdout)
           sys.exit(1)
        else:
           # '__debug__' This constant is true if Python was not started with an -O option
           if __debug__: print (GetFunctionName(), self._libcosim+" found.", flush=True)
     
        try:
            self._cosim = ctypes.CDLL(self._libcosim, ctypes.RTLD_GLOBAL)
        except:
            traceback.print_exc(file=sys.stdout)
            sys.exit(1)
    #-------------------------------------------------------------------------------
    def open_server( self ) -> int:
        """
        Open an IPC channel
        :param cid: integer, IPC channel ID
        :param port: integer, Socket port
        :return: 0 on success, otherwise return negative number
        """
        _cosim_open = WrapFunction( self._cosim
                                  , 'cosim_open_server'
                                  , ctypes.c_int
                                  ,[ctypes.c_int
                                  , ctypes.c_int])
        ret =  _cosim_open( self._cid, self._port )
        return ret
    
    #-------------------------------------------------------------------------------
    def open_client( self ) -> int:
        """
        Open an IPC channel
        :param cid: integer, IPC channel ID
        :param port: integer, Socket port
        :return: 0 on success, otherwise return negative number
        """
        _cosim_open = WrapFunction( self._cosim
                                  , 'cosim_open_client'
                                  , ctypes.c_int
                                  ,[ctypes.c_int
                                  , ctypes.c_int])
        ret =  _cosim_open( self._cid, self._port )
        return ret
    
    #-------------------------------------------------------------------------------
    # Open channel for server since HDL simulator will be client.
    # Any side running first should be server that can wait until client tries connect.
    def open( self ) -> int:
        if self._mode=='server':
            return self.open_server()
        elif self._mode=='client':
            return self.open_client()
        else:
            return -1;
    
    #---------------------------------------------------------------------------
    def close( self ) -> int:
        """
        Close the IPC channel.
        :param cid: integer, IPC channel ID
        :return: 0 on success, otherwise return negative number.
        """
        _cosim_close = WrapFunction( self._cosim
                                   , 'cosim_close'
                                   , ctypes.c_int
                                   ,[ctypes.c_int])
        return _cosim_close( self._cid )
    
    #---------------------------------------------------------------------------
    def barrier( self ) -> int:
        """
        Barrier
        :param cid: integer, IPC channel ID
        :return: 0 on success, otherwise return negative number.
        """
        _cosim_barrier = WrapFunction( self._cosim
                                     , 'cosim_barrier'
                                     , ctypes.c_int
                                     ,[ctypes.c_int])
        return _cosim_barrier( self._cid )
    
    #---------------------------------------------------------------------------
    def set_verbose( self, level:int=0 ) -> int:
        """
        Set verbose level.
        :param cid: integer, IPC channel ID
        :return: 0 on success, otherwise return negative number.
        """
        _cosim_set_verbose = WrapFunction( self._cosim
                                         , 'cosim_set_verbose'
                                         , ctypes.c_int
                                         ,[ctypes.c_int])
        ret = _cosim_set_verbose( level )
        if ret==0:
            self._verbose = level
        return ret
    
    #---------------------------------------------------------------------------
    def get_verbose( self ) -> int:
        """
        Return verbose level.
        :param cid: integer, IPC channel ID
        :return verbose level
        """
        _cosim_get_verbose = WrapFunction( self._cosim
                                         , 'cosim_get_verbose'
                                         , ctypes.c_int
                                         , None )
        return _cosim_get_verbose()
    
    #---------------------------------------------------------------------------
    def snd( self, payload:bytearray, size:int ) -> int:
        """
        Generate write transaction
        :param payload: array (list) holding 8-bit data, which is byte-stream in little-endian
        :param size: number of bytes in payload
        :return: the number of bytes sent
        """
        if self._rigor>0:
            if type(payload) is not bytearray and type(payload) is not bytes:
                CosimError(f"{GetFunctionName()} data type error", flush=True)
                return -1
        _cosim_snd = WrapFunction( self._cosim
                                 , 'cosim_snd'
                                 , ctypes.c_int
                                 ,[ctypes.c_int
                                 , ctypes.POINTER(ctypes.c_ubyte)
                                 , ctypes.c_int])
        pdata = (ctypes.c_ubyte * len(payload))(*payload)
        ret = _cosim_snd(self._cid, pdata, size)
        return ret
    
    #---------------------------------------------------------------------------
    def rcv( self, payload:bytearray, size:int ) -> int:
        """
        Generate read transaction
        :param cid:
        :param payload: array (list) holding 8-bit data, which is byte-stream in little-endian
        :param size: number of bytes
        :return: the number of bytes received
        """
        if self._rigor>0:
            if type(payload) is not bytearray and type(payload) is not bytes:
                CosimError(f"{GetFunctionName()} data type error", flush=True)
                return -1
        _cosim_rcv = WrapFunction( self._cosim
                                 , 'cosim_rcv'
                                 , ctypes.c_int
                                 ,[ctypes.c_int
                                 , ctypes.POINTER(ctypes.c_ubyte)
                                 , ctypes.c_int ])
        pdata = (ctypes.c_ubyte * len(payload))(*payload)
        ret = _cosim_rcv(self._cid, pdata, size)
        if ret>0:
            for i in range(ret): payload[i] = pdata[i]
        return ret

#===============================================================================
def test_server(cid=0
               ,port=0x2300
               ,rigor=0
               ,verbose=0):

    hdl = CoSim(cid,port,'server',rigor,verbose)

    bnum = 0x20
    Data = bytearray([0x00] * bnum)
    for i in range(bnum): Data[i] = i+1;

    hdl.rcv( Data, bnum )

    for i in range(bnum): Data[i] += 1;

    hdl.snd( Data, bnum )

    del hdl

#-------------------------------------------------------------------------------
def test_client(cid=0
               ,port=0x2300
               ,rigor=False
               ,verbose=False):

    hdl = CoSim(cid,port,'client',rigor,verbose)

    bnum = 0x20
    WData = bytearray([0x00] * bnum)
    RData = bytearray([0x00] * bnum)
    for i in range(bnum): WData[i] = i+1;

    hdl.snd( WData, bnum)
    hdl.rcv( RData, bnum)

    error = 0
    for i in range(bnum):
        if (WData[i]+1)!=RData[i]: error = error + 1;
        #else: print(f"[{i}]={WData[i]}:{RData[i]}")

    if error>0:
        print(f"{GetFunctionName()} mis-match {error} out of {bnum} bytes")
    else:
        print(f"{GetFunctionName()} OK {bnum} bytes")

    del hdl

#-------------------------------------------------------------------------------
if __name__=='__main__':
    import getopt
    import multiprocessing

    cid    = 0; #default channel id.
    port   = 0x2300; #default socket port.
    rigor  = 0
    verbose= 0

    try:
        opts, args = getopt.getopt(sys.argv[1:], "hg:r:C:P:S:", ['help'
                                                              ,'verbose='
                                                              ,'rigor='
                                                              ,'cid='
                                                              ,'port='])
    except getopt.GetoptError:
        sys.exit(2)
    else:
        for opt, arg in opts:
            if opt in ("-h", "--help"):
                print(f"{sys.argv[0]} [options]")
                print(f" -h/--help: help")
                print(f" -g/--verbose=num: set verbose level")
                print(f" -r/--rigor=num: set rigor level")
                print(f" -C/--cid=num: set channel id")
                print(f" -P/--port=num: set socket port")
                sys.exit()
            elif opt in ("-C","--cid"):
                cid = int(arg, 0)
            elif opt in ("-P","--port"):
                port = int(arg, 0)
            elif opt in ("-r","--rigor"):
                rigor = int(arg, 0)
            elif opt in ("-g","--verbose"):
                verbose = int(arg, 0)
            else:
                print("Unknown options: "+str(opt))
                sys.exit(1)

    srv = multiprocessing.Process(name="server", target=test_server, args=(cid, port, rigor, verbose));
    cli = multiprocessing.Process(name="client", target=test_client, args=(cid, port, rigor, verbose));

    srv.start()
    cli.start()

    srv.join()
    cli.join()

#===============================================================================
# Revision history:
#
# 2022.11.18: Started        by Ando Ki     (andoki@gmail.com)
#===============================================================================
