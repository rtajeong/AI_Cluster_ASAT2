# The __init__.py file makes Python treat directories containing it as modules.
# 1. Hide cosim Python package hierarchy
# 2. Somthing to be initialized
#
# "from cosim.cosim_api import *", where 'cosim' is package.
# The funy single dot before module name is read as "current package"

from .cosim_api import *
from .cosim_bfm_axi import *
