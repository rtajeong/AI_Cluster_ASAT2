#include "my_printf.h"
#include "uart_api.h"
#define ADDR_UART  0x10000000

int main()
{
#if 1
    uart_set_addr(ADDR_UART);
    unsigned int freq=uart_get_clk_freq();
    uart_init( freq, 115200, 8, 0, 1 ); // freq,baud,width,parity,stop
    uart_put_string("Hello world!\r\n");

    my_printf("Hello again!\n");
#else
    volatile unsigned int *pt=(unsigned int*)0x10000000;
    volatile unsigned int valueW=0x21436587;
    volatile unsigned int valueR=0x00000000;
    *pt = valueW;
    valueR = *pt;
#endif
    return 0;
}
