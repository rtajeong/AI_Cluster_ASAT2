#include "cosim_bfm_axi.h"
#if 0
#include <riscv/mmio_plugin.h>
#else
#include "mmio_plugin.h"
#endif
#include <stdio.h>
#include <stdlib.h>

struct ctx_t {
    int level;
    int cid;
    int port;
};

void* hw_mmio_plugin_alloc(const char* args)
{
    struct ctx_t *pctx=(struct ctx_t *)malloc(sizeof(struct ctx_t));
    pctx->level=1;
    pctx->cid=0;
    pctx->port=0x2300;
    printf("%s(%s)\n", __func__, args);
    cosim_set_verbose(pctx->level);
    cosim_bfm_axi_open(pctx->cid, pctx->port);
    return (void*)(pctx);
  //return (void*)((intptr_t)cid);
  //return reinterpret_cast<void*>(cid);
}

bool hw_mmio_plugin_load(void* self, reg_t addr, size_t len, uint8_t* bytes)
{
    struct ctx_t *pctx=(struct ctx_t *)(self);
    cosim_bfm_axi_read( (uint64_t)addr, bytes, (unsigned int)len, 1, pctx->cid);
#if 0
    printf("LOAD -- SELF=%p ADDR=0x%lx LEN=%lu BYTES=0x", self, addr, len);
    for (int idx=0; idx<len; idx++) {
        printf("%02X", bytes[idx]);
    }
    printf("\n");
#endif
    return true;
}

bool hw_mmio_plugin_store(void* self, reg_t addr, size_t len, const uint8_t* bytes)
{
#if 0
    printf("STORE -- SELF=%p ADDR=0x%lx LEN=%lu BYTES=0x", self, addr, len);
    for (int idx=0; idx<len; idx++) {
        printf("%02X", bytes[idx]);
    }
    printf("\n");
#endif
    struct ctx_t *pctx=(struct ctx_t *)(self);
    cosim_bfm_axi_write( (uint64_t)addr, (uint8_t *)bytes, (unsigned int)len, 1, pctx->cid);
    return true;
}

void hw_mmio_plugin_dealloc(void* self)
{
    printf("%s(%p)\n", __func__, self);
    struct ctx_t *pctx=(struct ctx_t *)(self);
  //int cid = reinterpret_cast<int>(self)
  //int cid = (intptr_t)self;
    if (pctx!=NULL) {
        cosim_bfm_axi_finish(pctx->cid);
        cosim_bfm_axi_close(pctx->cid);
        free(pctx);
    }
}

__attribute__((constructor)) static void on_load(void)
{
  static mmio_plugin_t hw_mmio_plugin = {
      hw_mmio_plugin_alloc,
      hw_mmio_plugin_load,
      hw_mmio_plugin_store,
      hw_mmio_plugin_dealloc
  };

  register_mmio_plugin("hw_mmio_plugin", &hw_mmio_plugin);
}

