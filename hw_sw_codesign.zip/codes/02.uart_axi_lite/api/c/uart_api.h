#ifndef _UART_H_
#define _UART_H_
//--------------------------------------------------------
//  Copyright (c) 2024 by Ando Ki.
//  All right reserved.
//
// This program is distributed in the hope that it
// will be useful to understand Ando Ki's work,
// BUT WITHOUT ANY WARRANTY.
//--------------------------------------------------------

void         uart_init( unsigned int freq
                      , unsigned int baudrate
                      , unsigned int width
                      , unsigned int parity
                      , unsigned int stop);
unsigned int uart_get_char(void);
unsigned int uart_put_char(char d);
int          uart_put_string(char* s);
unsigned int uart_get_clk_freq(void);
void         uart_set_addr( unsigned int addr );
unsigned int uart_get_addr( void );

//--------------------------------------------------------
// Revision history
//
// 2024.08.10: Started by Ando Ki (andoki@gmail.com)
//--------------------------------------------------------
#endif
