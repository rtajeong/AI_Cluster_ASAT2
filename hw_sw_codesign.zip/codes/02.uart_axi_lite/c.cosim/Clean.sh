#!/bin/bash

/bin/rm -f test
