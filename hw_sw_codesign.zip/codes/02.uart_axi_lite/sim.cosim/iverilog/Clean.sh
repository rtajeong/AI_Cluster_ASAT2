#!/usr/bin/env bash

if [ -f top.vvp     ]; then  /bin/rm -f  top.vvp    ; fi
if [ -f vvp.log     ]; then  /bin/rm -f  vvp.log    ; fi
if [ -f compile.log ]; then  /bin/rm -f  compile.log; fi
if [ -f wave.vcd    ]; then  /bin/rm -f  wave.vcd   ; fi
