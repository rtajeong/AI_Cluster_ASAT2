#!/bin/bash -f
#------------------------------------------------------
# Copyright (c) 2024 by Ando Ki
#------------------------------------------------------
# VERSION: 2024.08.20.
#------------------------------------------------------
SHELL=/bin/bash

# rv64/lp64
# rv64imac/lp64
# rv64gc/lp64d   #RV64GC = RV64IMAFDCZicsr_Zifencei
# rv64imafdc/lp64d

bits=64

./BuildRiscvCore.sh -bits      ${bits}\
                    -prefix    ${HOME}/riscv${bits}\
                    -host      riscv${bits}-unknown-elf\
                    -arch      rv${bits}gc\
                    -multi     1\
                    -compiler  1\
                    -gdb       0\
                    -simulator 1\
                    -pk        1\
                    -build     build${bits}

#------------------------------------------------------
# Revision history:
#
# 2024.08.20: Started by Ando Ki (andoki@gmail.com)
#------------------------------------------------------
